/*
 * C++ Library file new.h
 * (After Stroustrup, "The C++ Programming Language", section 3.2.6)
 * Copyright 1993 ARM Limited. All rights reserved.
 * Copyright (C) Codemist Limited, 1994.
 */

/*
 * RCS $Revision: 1.14 $
 * Checkin $Date: 2001/01/05 14:52:12 $
 * Revising $Author: vkorstan $
 */

#ifndef __NEW_H
#define __NEW_H
#include <new>
#endif

/* End of new.h */
