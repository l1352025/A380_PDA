SELECT * FROM program
WHERE SizeKB > :SizeInKb  /* ParamType=Integer */
ORDER BY SizeKB