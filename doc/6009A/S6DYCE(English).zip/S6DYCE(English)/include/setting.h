/*
 * setting.h
 *
 *  Created on: 2015��6��24��
 *      Author: iwork
 */

#ifndef SETTING_H_
#define SETTING_H_

#endif /* SETTING_H_ */
