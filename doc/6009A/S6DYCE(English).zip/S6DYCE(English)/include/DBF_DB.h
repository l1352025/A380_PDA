
#ifndef DBF_DB_H_
#define DBF_DB_H_

#define XBASE_FLDHDR_SZ        32

typedef struct
{
	FILE        *fp;                                   //�ļ�ָ��
	long        nRecords;                              //��¼��
	long        nRecordLength;                         //��¼����
	int         nHeaderLength;                         //�ļ�ͷ����
	int         nFields;                               //�ֶ���
	int         *panFieldOffset;                       //�ֶ�ƫ�Ƶ�ַָ��
	int         *panFieldSize;                         //�ֶγ���ָ��
	int         *panFieldDecimals;                     //С��λ��ָ��
	char        *pachFieldType;                        //�ֶ�����ָ��
	char        *pszHeader;                            //�ֶ�ָ��
	long         nCurrentRecord;                       //��ǰ��¼���
	int         bCurrentRecordModified;                //��ǰ��¼�޸ı�־
	char        *pszCurrentRecord;                     //��ǰ��¼ָ��
	int         nWorkFieldLength;                      //��ǰ�ֶγ���
	char        *pszWorkField;                         //��ǰ�ֶ�����ָ��
	int         bNoHeader;                             //û���ļ�ͷ��־
	int         bUpdated;                              //��¼���±�־
	double      dfDoubleField;                         //
} DBFInfo;

typedef DBFInfo* DBFHandle;

typedef enum{FTString,FTInteger,FTDouble,FTLogical,FTInvalid} DBFFieldType;

//�����ݿ�
void * SfRealloc( void * pMem, int nNewSize );
DBFHandle DBFOpen( const char * pszFilename, const char * pszAccess );
DBFHandle OpenDBF(const char * pszFilename, const char * pStr);

//�ر����ݿ�
void DBFClose(DBFHandle psDBF);
void CloseDBF(DBFHandle pDBF);

//�������ݿ�
void DBFWriteHeader(DBFHandle psDBF);
int DBFFlushRecord( DBFHandle psDBF );
void DBFUpdateHeader( DBFHandle psDBF );

//ͳ�Ƽ�¼��
int DBFGetRecordCount( DBFHandle psDBF );
//DBFGetFieldIndex()
int DBFGetFieldIndex(DBFHandle psDBF, const char *pszFieldName);
// str_to_upper()
void str_to_upper (char *string);
//DBFGetFieldCount()
int DBFGetFieldCount( DBFHandle psDBF );
//DBFGetFieldInfo()
DBFFieldType  DBFGetFieldInfo( DBFHandle psDBF, int iField, char * pszFieldName,int * pnWidth, int * pnDecimals );

char * DBFReadStringAttribute( DBFHandle psDBF, int iRecord, int iField );
int DBFReadIntegerAttribute( DBFHandle psDBF, int iRecord, int iField );

void *DBFReadAttribute(DBFHandle psDBF, int hEntity, int iField,char chReqType );
int DBFLoadRecord( DBFHandle psDBF, int iRecord );


int DBFWriteStringAttribute( DBFHandle psDBF, int iRecord, int iField,const char * pszValue );
int DBFWriteAttribute(DBFHandle psDBF, int hEntity, int iField,void * pValue );

int DBFWriteIntegerAttribute( DBFHandle psDBF, int iRecord, int iField,  int nValue );
#endif /* DBF_DB_H_ */
