/*
 * DBF_DB.cpp
 *
 *  Created on: 2015��6��26��
 *      Author: iwork
 */
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "DBF_DB.h"
#include "display.h"

/******************************************************************************
** 01
** �����ݿ�
*****************************************************************************/
DBFHandle OpenDBF(const char * pszFilename, const char * pStr)
{
    DBFHandle           psDBF;

    psDBF=DBFOpen(pszFilename,pStr);
    return( psDBF );
}

/******************************************************************************
** 02
** �ر����ݿ�
*****************************************************************************/
void CloseDBF(DBFHandle pDBF)
{
    DBFClose(pDBF);
}

/************************************************************************/
/*                         DBFGetRecordCount()                          */
/*                                                                      */
/*      Return the number of records in this table.                     */
/************************************************************************/

int DBFGetRecordCount( DBFHandle psDBF )
{
    long tRecords;

    tRecords = psDBF->nRecords;
    if (tRecords > 20000) {
        tRecords = 20000;
    }
    return( tRecords );
}

/************************************************************************/
/*                          DBFGetFieldIndex()                          */
/*                                                                      */
/*      Get the index number for a field in a .dbf file.                */
/*                                                                      */
/*      Contributed by Jim Matthews.                                    */
/************************************************************************/

int DBFGetFieldIndex(DBFHandle psDBF, const char *pszFieldName)
{
    char		  name[12], name1[12], name2[12];
    int 		  i;

    strncpy(name1, pszFieldName,11);
    name1[11] = '\0';
    str_to_upper(name1);

    for ( i = 0; i < DBFGetFieldCount(psDBF); i++ ) {
        DBFGetFieldInfo( psDBF, i, name, NULL, NULL );
        strncpy(name2,name,11);
        str_to_upper(name2);

        if (!strncmp(name1,name2,10))
            return(i);
    }
    return(-1);
}


/************************************************************************/
/*                            str_to_upper()                            */
/************************************************************************/

void str_to_upper (char *string)
{
    int len;
    short i = -1;

    len = strlen (string);

    while (++i < len)
        if (isalpha(string[i]) && islower(string[i]))
            string[i] = (char) toupper ((int)string[i]);
}


/************************************************************************/
/*                          DBFGetFieldCount()                          */
/*                                                                      */
/*      Return the number of fields in this table.                      */
/************************************************************************/

int DBFGetFieldCount( DBFHandle psDBF )
{
    return( psDBF->nFields );
}


/************************************************************************/
/*                          DBFGetFieldInfo()                           */
/*                                                                      */
/*      Return any requested information about the field.               */
/************************************************************************/

DBFFieldType DBFGetFieldInfo( DBFHandle psDBF, int iField, char * pszFieldName, int * pnWidth, int * pnDecimals )
{
    if ( iField < 0 || iField >= psDBF->nFields )
        return( FTInvalid );

    if ( pnWidth != NULL )
        *pnWidth = psDBF->panFieldSize[iField];

    if ( pnDecimals != NULL )
        *pnDecimals = psDBF->panFieldDecimals[iField];

    if ( pszFieldName != NULL ) {
        int     i;

        strncpy( pszFieldName, (char *) psDBF->pszHeader+iField*32, 11 );
        pszFieldName[11] = '\0';
        for ( i = 10; i > 0 && pszFieldName[i] == ' '; i-- )
            pszFieldName[i] = '\0';
    }

    if ( psDBF->pachFieldType[iField] == 'L' )
        return( FTLogical);

    else if ( psDBF->pachFieldType[iField] == 'N' 
        || psDBF->pachFieldType[iField] == 'F' ) {
            if ( psDBF->panFieldDecimals[iField] > 0 )
                /*            || psDBF->panFieldSize[iField] > 10 ) */ /* GDAL bug #809 */
                return( FTDouble );
            else
                return( FTInteger );
    } else {
        return( FTString );
    }
}

/************************************************************************/
/*                             SfRealloc()                              */
/*                                                                      */
/*      A realloc cover function that will access a NULL pointer as     */
/*      a valid input.                                                  */
/************************************************************************/
void * SfRealloc( void * pMem, int nNewSize )
{
    if ( pMem == NULL )
        return( (void *) malloc(nNewSize) );
    else
        return( (void *) realloc(pMem,nNewSize) );
}
/************************************************************************/
/*                              DBFOpen()                               */
/*                                                                      */
/*      Open a .dbf file.                                               */
/************************************************************************/

DBFHandle DBFOpen( const char * pszFilename, const char * pszAccess )

{
    DBFHandle           psDBF;
    unsigned char       *pabyBuf;
    int                 nFields, nHeadLen, iField, i;
    char                *pszBasename, *pszFullname;

    /* -------------------------------------------------------------------- */
    /*      We only allow the access strings "rb" and "r+".                  */
    /* -------------------------------------------------------------------- */
    if ( strcmp(pszAccess,"r") != 0 && strcmp(pszAccess,"r+") != 0
        && strcmp(pszAccess,"rb") != 0 && strcmp(pszAccess,"rb+") != 0
        && strcmp(pszAccess,"r+b") != 0 )
        return( NULL );

    if ( strcmp(pszAccess,"r") == 0 )
        pszAccess = "rb";

    if ( strcmp(pszAccess,"r+") == 0 )
        pszAccess = "rb+";

    /* -------------------------------------------------------------------- */
    /*      Compute the base (layer) name.  If there is any extension       */
    /*      on the passed in filename we will strip it off.                 */
    /* -------------------------------------------------------------------- */
    pszBasename = (char *) malloc(strlen(pszFilename)+5);
    strcpy( pszBasename, pszFilename );
    for ( i = strlen(pszBasename)-1;
        i > 0 && pszBasename[i] != '.' && pszBasename[i] != '/'
        && pszBasename[i] != '\\';
    i-- ) {
    }

    if ( pszBasename[i] == '.' )
        pszBasename[i] = '\0';

    pszFullname = (char *) malloc(strlen(pszBasename) + 5);
    sprintf( pszFullname, "%s.dbf", pszBasename );

    psDBF = (DBFHandle) calloc( 1, sizeof(DBFInfo) );
    psDBF->fp = fopen( pszFullname, pszAccess );

    if ( psDBF->fp == NULL ) {
        sprintf( pszFullname, "%s.DBF", pszBasename );
        psDBF->fp = fopen(pszFullname, pszAccess );
    }

    free( pszBasename );
    free( pszFullname );

    if ( psDBF->fp == NULL ) {
        free( psDBF );
        return( NULL );
    }

    psDBF->bNoHeader = false;
    psDBF->nCurrentRecord = -1;
    psDBF->bCurrentRecordModified = false;

    /* -------------------------------------------------------------------- */
    /*  Read Table Header info                                              */
    /* -------------------------------------------------------------------- */
    pabyBuf = (unsigned char *) malloc(500);
    if ( fread( pabyBuf, 32, 1, psDBF->fp ) != 1 ) {
        fclose( psDBF->fp );
        free( pabyBuf );
        free( psDBF );
        return NULL;
    }

    //Modify by Godwin 2009/06/08
    //#######################################################################//
    /**
    psDBF->nRecords = pabyBuf[4] + pabyBuf[5]*256 + pabyBuf[6]*256*256 + pabyBuf[7]*256*256*256;
    **/
    psDBF->nRecords = pabyBuf[4] + pabyBuf[5]*256 + pabyBuf[6]*65536 + pabyBuf[7]*16777216;
    //#######################################################################//
    psDBF->nHeaderLength = nHeadLen = pabyBuf[8] + pabyBuf[9]*256;
    psDBF->nRecordLength = pabyBuf[10] + pabyBuf[11]*256;

    psDBF->nFields = nFields = (nHeadLen - 32) / 32;

    psDBF->pszCurrentRecord = (char *) malloc(psDBF->nRecordLength);

    /* -------------------------------------------------------------------- */
    /*  Read in Field Definitions                                           */
    /* -------------------------------------------------------------------- */

    pabyBuf = (unsigned char *) SfRealloc(pabyBuf,nHeadLen);
    psDBF->pszHeader = (char *) pabyBuf;

    fseek( psDBF->fp, 32, 0 );
    if ( fread( pabyBuf, nHeadLen-32, 1, psDBF->fp ) != 1 ) {
        fclose( psDBF->fp );
        free( pabyBuf );
        free( psDBF->pszCurrentRecord );
        free( psDBF );
        return NULL;
    }

    psDBF->panFieldOffset = (int *) malloc(sizeof(int) * nFields);
    psDBF->panFieldSize = (int *) malloc(sizeof(int) * nFields);
    psDBF->panFieldDecimals = (int *) malloc(sizeof(int) * nFields);
    psDBF->pachFieldType = (char *) malloc(sizeof(char) * nFields);

    for ( iField = 0; iField < nFields; iField++ ) {
        unsigned char           *pabyFInfo;

        pabyFInfo = pabyBuf+iField*32;

        if ( pabyFInfo[11] == 'N' || pabyFInfo[11] == 'F' ) {
            psDBF->panFieldSize[iField] = pabyFInfo[16];
            psDBF->panFieldDecimals[iField] = pabyFInfo[17];
        } else {
            psDBF->panFieldSize[iField] = pabyFInfo[16];
            psDBF->panFieldDecimals[iField] = 0;

            /*
            ** The following seemed to be used sometimes to handle files with long
            ** string fields, but in other cases (such as bug 1202) the decimals field
            ** just seems to indicate some sort of preferred formatting, not very
            ** wide fields.  So I have disabled this code.  FrankW.
            psDBF->panFieldSize[iField] = pabyFInfo[16] + pabyFInfo[17]*256;
            psDBF->panFieldDecimals[iField] = 0;
            */
        }

        psDBF->pachFieldType[iField] = (char) pabyFInfo[11];
        if ( iField == 0 )
            psDBF->panFieldOffset[iField] = 1;
        else
            psDBF->panFieldOffset[iField] =
            psDBF->panFieldOffset[iField-1] + psDBF->panFieldSize[iField-1];
    }

    return( psDBF );
}

/************************************************************************/
/*                              DBFClose()                              */
/************************************************************************/

void DBFClose(DBFHandle psDBF)
{
    /* -------------------------------------------------------------------- */
    /*      Write out header if not already written.                        */
    /* -------------------------------------------------------------------- */
    if ( psDBF->bNoHeader )
        DBFWriteHeader( psDBF );

    DBFFlushRecord( psDBF );

    /* -------------------------------------------------------------------- */
    /*      Update last access date, and number of records if we have       */
    /*      write access.                                                   */
    /* -------------------------------------------------------------------- */
    if ( psDBF->bUpdated )
	{
		 DBFUpdateHeader( psDBF );
	}

    /* -------------------------------------------------------------------- */
    /*      Close, and free resources.                                      */
    /* -------------------------------------------------------------------- */
    fclose( psDBF->fp );

    if ( psDBF->panFieldOffset != NULL ) {
        free( psDBF->panFieldOffset );
        free( psDBF->panFieldSize );
        free( psDBF->panFieldDecimals );
        free( psDBF->pachFieldType );
    }

    if ( psDBF->pszWorkField != NULL )
        free( psDBF->pszWorkField );

    free( psDBF->pszHeader );
    free( psDBF->pszCurrentRecord );

    free( psDBF );
}

/************************************************************************/
/*                           DBFWriteHeader()                           */
/*                                                                      */
/*      This is called to write out the file header, and field          */
/*      descriptions before writing any actual data records.  This      */
/*      also computes all the DBFDataSet field offset/size/decimals     */
/*      and so forth values.                                            */
/************************************************************************/
void DBFWriteHeader(DBFHandle psDBF)
{
    unsigned char       abyHeader[XBASE_FLDHDR_SZ];
    int         i;

    if ( !psDBF->bNoHeader )
        return;

    psDBF->bNoHeader = false;

    /* -------------------------------------------------------------------- */
    /*      Initialize the file header information.                         */
    /* -------------------------------------------------------------------- */
    for ( i = 0; i < XBASE_FLDHDR_SZ; i++ )
        abyHeader[i] = 0;

    abyHeader[0] = 0x03;                /* memo field? - just copying   */

    /* write out a dummy date */
    abyHeader[1] = 95;                  /* YY */
    abyHeader[2] = 7;                   /* MM */
    abyHeader[3] = 26;                  /* DD */

    /* record count preset at zero */

    abyHeader[8] = (unsigned char) (psDBF->nHeaderLength % 256);
    abyHeader[9] = (unsigned char) (psDBF->nHeaderLength / 256);

    abyHeader[10] = (unsigned char) (psDBF->nRecordLength % 256);
    abyHeader[11] = (unsigned char) (psDBF->nRecordLength / 256);

    /* -------------------------------------------------------------------- */
    /*      Write the initial 32 byte file header, and all the field        */
    /*      descriptions.                                                   */
    /* -------------------------------------------------------------------- */
    fseek( psDBF->fp, 0, 0 );
    fwrite( abyHeader, XBASE_FLDHDR_SZ, 1, psDBF->fp );
    fwrite( psDBF->pszHeader, XBASE_FLDHDR_SZ, psDBF->nFields, psDBF->fp );

    /* -------------------------------------------------------------------- */
    /*      Write out the newline character if there is room for it.        */
    /* -------------------------------------------------------------------- */
    if ( psDBF->nHeaderLength > 32*psDBF->nFields + 32 ) {
        char    cNewline;

        cNewline = 0x0d;
        fwrite( &cNewline, 1, 1, psDBF->fp );
    }
}

/************************************************************************/
/*                           DBFFlushRecord()                           */
/*                                                                      */
/*      Write out the current record if there is one.                   */
/************************************************************************/
int DBFFlushRecord( DBFHandle psDBF )
{
	char ErrorString[50],RecordString[10];
    //Modify by Godwin 2009/06/08
    //#######################################################################//
    /**
    int nRecordOffset;
    **/
    long   nRecordOffset;
    //#######################################################################//

    if ( psDBF->bCurrentRecordModified && psDBF->nCurrentRecord > -1 ) {
        psDBF->bCurrentRecordModified = false;

        nRecordOffset = psDBF->nRecordLength * psDBF->nCurrentRecord + psDBF->nHeaderLength;

        if ( fseek( psDBF->fp, nRecordOffset, 0 ) != 0 || fwrite( psDBF->pszCurrentRecord, psDBF->nRecordLength, 1, psDBF->fp ) != 1 ) {
#ifdef USE_CPL
                CPLError( CE_Failure, CPLE_FileIO, "Failure writing DBF record %d.",psDBF->nCurrentRecord );
#else
                strcpy(ErrorString,"Failure writing DBF record");
                sprintf(RecordString,"%d",(int)psDBF->nCurrentRecord);
                strcat(ErrorString,RecordString);
				printf("%s\n",ErrorString);
                //ew_display_string(16,16,(unsigned char*)ErrorString,rgb888_to_rgb565(0x0000FF),0x10 | 1);
#endif
                return false;
        }
    }

    return true;
}


/************************************************************************/
/*                          DBFUpdateHeader()                           */
/************************************************************************/

void DBFUpdateHeader( DBFHandle psDBF )
{
    unsigned char               abyFileHeader[32];

    if ( psDBF->bNoHeader )
        DBFWriteHeader( psDBF );

    DBFFlushRecord( psDBF );

    fseek( psDBF->fp, 0, 0 );
    fread( abyFileHeader, 32, 1, psDBF->fp );
    //Modify by Godwin 2007/09/25
    //#######################################################################//
    /**
    abyFileHeader[4] = (unsigned char) (psDBF->nRecords % 256);
    abyFileHeader[5] = (unsigned char) ((psDBF->nRecords/256) % 256) ;
    abyFileHeader[6] = (unsigned char) ((psDBF->nRecords/(256*256)) % 256);
    abyFileHeader[7] = (unsigned char) ((psDBF->nRecords/(256*256*256)) % 256);
    **/
    abyFileHeader[4] = (unsigned char) (psDBF->nRecords % 256);
    abyFileHeader[5] = (unsigned char) ((psDBF->nRecords/256) % 256) ;
    abyFileHeader[6] = (unsigned char) ((psDBF->nRecords/(65536)) % 256);
    abyFileHeader[7] = (unsigned char) ((psDBF->nRecords/(16777216)) % 256);
    //#######################################################################//
    fseek( psDBF->fp, 0, 0 );
    fwrite( abyFileHeader, 32, 1, psDBF->fp );

    fflush( psDBF->fp );
}

/************************************************************************/
/*                        DBFReadStringAttribute()                      */
/*                                                                      */
/*      Read a string attribute.                                        */
/************************************************************************/

char * DBFReadStringAttribute( DBFHandle psDBF, int iRecord, int iField )

{
    return( (char *) DBFReadAttribute( psDBF, iRecord, iField, 'C' ) );
}


/************************************************************************/
/*                        DBFReadIntAttribute()                         */
/*                                                                      */
/*      Read an integer attribute.                                      */
/************************************************************************/

int DBFReadIntegerAttribute( DBFHandle psDBF, int iRecord, int iField )

{
    double      *pdValue;

    pdValue = (double *) DBFReadAttribute( psDBF, iRecord, iField, 'N' );

    if ( pdValue == NULL )
        return 0;
    else
        return( (int) *pdValue );
}


/************************************************************************/
/*                          DBFReadAttribute()                          */
/*                                                                      */
/*      Read one of the attribute fields of a record.                   */
/************************************************************************/
void *DBFReadAttribute(DBFHandle psDBF, int hEntity, int iField,char chReqType )
{
    unsigned char       *pabyRec;
    void        *pReturnField = NULL;

    /* -------------------------------------------------------------------- */
    /*      Verify selection.                                               */
    /* -------------------------------------------------------------------- */
    if ( hEntity < 0 || hEntity >= psDBF->nRecords )
        return( NULL );

    if ( iField < 0 || iField >= psDBF->nFields )
        return( NULL );

    /* -------------------------------------------------------------------- */
    /*      Have we read the record?                                        */
    /* -------------------------------------------------------------------- */
    if ( !DBFLoadRecord( psDBF, hEntity ) )
        return NULL;

    pabyRec = (unsigned char *) psDBF->pszCurrentRecord;

    /* -------------------------------------------------------------------- */
    /*      Ensure we have room to extract the target field.                */
    /* -------------------------------------------------------------------- */
    if ( psDBF->panFieldSize[iField] >= psDBF->nWorkFieldLength ) {
        psDBF->nWorkFieldLength = psDBF->panFieldSize[iField] + 100;
        if ( psDBF->pszWorkField == NULL )
            psDBF->pszWorkField = (char *) malloc(psDBF->nWorkFieldLength);
        else
            psDBF->pszWorkField = (char *) realloc(psDBF->pszWorkField,
            psDBF->nWorkFieldLength);
    }

    /* -------------------------------------------------------------------- */
    /*      Extract the requested field.                                    */
    /* -------------------------------------------------------------------- */
    strncpy( psDBF->pszWorkField,
        ((const char *) pabyRec) + psDBF->panFieldOffset[iField],
        psDBF->panFieldSize[iField] );
    psDBF->pszWorkField[psDBF->panFieldSize[iField]] = '\0';

    pReturnField = psDBF->pszWorkField;

    /* -------------------------------------------------------------------- */
    /*      Decode the field.                                               */
    /* -------------------------------------------------------------------- */
    if ( chReqType == 'N' ) {
        psDBF->dfDoubleField = atof(psDBF->pszWorkField);

        pReturnField = &(psDBF->dfDoubleField);
    }

    /* -------------------------------------------------------------------- */
    /*      Should we trim white space off the string attribute value?      */
    /* -------------------------------------------------------------------- */
#ifdef TRIM_DBF_WHITESPACE
    else {
        char    *pchSrc, *pchDst;

        pchDst = pchSrc = psDBF->pszWorkField;
        while ( *pchSrc == ' ' )
            pchSrc++;

        while ( *pchSrc != '\0' )
            *(pchDst++) = *(pchSrc++);
        *pchDst = '\0';

        while ( pchDst != psDBF->pszWorkField && *(--pchDst) == ' ' )
            *pchDst = '\0';
    }
#endif

    return( pReturnField );
}

/************************************************************************/
/*                           DBFLoadRecord()                            */
/************************************************************************/
int DBFLoadRecord( DBFHandle psDBF, int iRecord )
{
	char ErrorString[50],RecordString[10];
    if ( psDBF->nCurrentRecord != iRecord ) {
        //Modify by Godwin 2009/06/08
        //#######################################################################//
        /**
        int nRecordOffset;
        **/
        long nRecordOffset;
        //#######################################################################//
        if ( !DBFFlushRecord( psDBF ) ) return false;
        nRecordOffset = psDBF->nRecordLength * iRecord + psDBF->nHeaderLength;
        if ( fseek( psDBF->fp, nRecordOffset, 0 ) != 0 ) {
#ifdef USE_CPL
            CPLError( CE_Failure, CPLE_FileIO, "fseek(%d) failed on DBF file.\n",  nRecordOffset );
#else

            sprintf(RecordString,"%d",(int)nRecordOffset);
            strcpy(ErrorString,"fseek ");
            strcat(ErrorString,RecordString);
            strcat(ErrorString," failed on DBF file.\n");
			printf("%s\n",ErrorString);
            //ew_display_string(16,16,(unsigned char*)ErrorString,rgb888_to_rgb565(0x0000FF),0x10 | 1);
#endif
            return false;
        }
        if ( fread( psDBF->pszCurrentRecord, psDBF->nRecordLength, 1, psDBF->fp ) != 1 ) {
#ifdef USE_CPL
            CPLError( CE_Failure, CPLE_FileIO, "fread(%d) failed on DBF file.\n", psDBF->nRecordLength );
#else

            sprintf(RecordString,"%d",(int)psDBF->nRecordLength);
            strcpy(ErrorString,"fread ");
            strcat(ErrorString,RecordString);
            strcat(ErrorString," failed on DBF file.\n");
			printf("%s\n",ErrorString);
            //ew_display_string(16,16,(unsigned char*)ErrorString,rgb888_to_rgb565(0x0000FF),0x10 | 1);
#endif
            return false;
        }

        psDBF->nCurrentRecord = iRecord;
    }

    return true;
}


/************************************************************************/
/*                      DBFWriteStringAttribute()                       */
/*                                                                      */
/*      Write a string attribute.                                       */
/************************************************************************/
int DBFWriteStringAttribute( DBFHandle psDBF, int iRecord, int iField,const char * pszValue )
{
    return( DBFWriteAttribute( psDBF, iRecord, iField, (void *) pszValue ) );
}


/************************************************************************/
/*                         DBFWriteAttribute()                          */
/*                                                                      */
/*      Write an attribute record to the file.                          */
/************************************************************************/
int DBFWriteAttribute(DBFHandle psDBF, int hEntity, int iField,void * pValue )
{
    int         i, j, nRetResult = true;
    unsigned char       *pabyRec;
    char        szSField[400], szFormat[20];

    /* -------------------------------------------------------------------- */
    /*      Is this a valid record?                                         */
    /* -------------------------------------------------------------------- */
    if ( hEntity < 0 || hEntity > psDBF->nRecords )
        return( false );

    if ( psDBF->bNoHeader )
        DBFWriteHeader(psDBF);

    /* -------------------------------------------------------------------- */
    /*      Is this a brand new record?                                     */
    /* -------------------------------------------------------------------- */
    if ( hEntity == psDBF->nRecords ) {
        if ( !DBFFlushRecord( psDBF ) )
            return false;

        psDBF->nRecords++;
        for ( i = 0; i < psDBF->nRecordLength; i++ )
            psDBF->pszCurrentRecord[i] = ' ';

        psDBF->nCurrentRecord = hEntity;
    }

    /* -------------------------------------------------------------------- */
    /*      Is this an existing record, but different than the last one     */
    /*      we accessed?                                                    */
    /* -------------------------------------------------------------------- */
    if ( !DBFLoadRecord( psDBF, hEntity ) )
        return false;

    pabyRec = (unsigned char *) psDBF->pszCurrentRecord;

    psDBF->bCurrentRecordModified = true;
    psDBF->bUpdated = true;

    /* -------------------------------------------------------------------- */
    /*      Translate NULL value to valid DBF file representation.          */
    /*                                                                      */
    /*      Contributed by Jim Matthews.                                    */
    /* -------------------------------------------------------------------- */
    if ( pValue == NULL ) {
        switch (psDBF->pachFieldType[iField]) {
        case 'N':
        case 'F':
            /* NULL numeric fields have value "****************" */
            memset( (char *) (pabyRec+psDBF->panFieldOffset[iField]), '*',
                psDBF->panFieldSize[iField] );
            break;

        case 'D':
            /* NULL date fields have value "00000000" */
            memset( (char *) (pabyRec+psDBF->panFieldOffset[iField]), '0',
                psDBF->panFieldSize[iField] );
            break;

        case 'L':
            /* NULL boolean fields have value "?" */
            memset( (char *) (pabyRec+psDBF->panFieldOffset[iField]), '?',
                psDBF->panFieldSize[iField] );
            break;

        default:
            /* empty string fields are considered NULL */
            memset( (char *) (pabyRec+psDBF->panFieldOffset[iField]), ' ',
                psDBF->panFieldSize[iField] );
            break;
        }
        return true;
    }

    /* -------------------------------------------------------------------- */
    /*      Assign all the record fields.                                   */
    /* -------------------------------------------------------------------- */
    switch ( psDBF->pachFieldType[iField] ) {
    case 'D':
    case 'N':
    case 'F':
        if ( psDBF->panFieldDecimals[iField] == 0 ) {
            int         nWidth = psDBF->panFieldSize[iField];

            if ( (int) sizeof(szSField)-2 < nWidth )
                nWidth = sizeof(szSField)-2;

            sprintf( szFormat, "%%%dd", nWidth );
            sprintf(szSField, szFormat, (int) *((double *) pValue) );
            if ( (int)strlen(szSField) > psDBF->panFieldSize[iField] ) {
                szSField[psDBF->panFieldSize[iField]] = '\0';
                nRetResult = false;
            }

            strncpy((char *) (pabyRec+psDBF->panFieldOffset[iField]),
                szSField, strlen(szSField) );
        } else {
            int         nWidth = psDBF->panFieldSize[iField];

            if ( (int) sizeof(szSField)-2 < nWidth )
                nWidth = sizeof(szSField)-2;

            sprintf( szFormat, "%%%d.%df",
                nWidth, psDBF->panFieldDecimals[iField] );
            sprintf(szSField, szFormat, *((double *) pValue) );
            if ( (int) strlen(szSField) > psDBF->panFieldSize[iField] ) {
                szSField[psDBF->panFieldSize[iField]] = '\0';
                nRetResult = false;
            }
            strncpy((char *) (pabyRec+psDBF->panFieldOffset[iField]),
                szSField, strlen(szSField) );
        }
        break;

    case 'L':
        if (psDBF->panFieldSize[iField] >= 1  &&
            (*(char*)pValue == 'F' || *(char*)pValue == 'T'))
            *(pabyRec+psDBF->panFieldOffset[iField]) = *(char*)pValue;
        break;

    default:
        if ( (int) strlen((char *) pValue) > psDBF->panFieldSize[iField] ) {
            j = psDBF->panFieldSize[iField];
            nRetResult = false;
        } else {
            memset( pabyRec+psDBF->panFieldOffset[iField], ' ',
                psDBF->panFieldSize[iField] );
            j = strlen((char *) pValue);
        }

        strncpy((char *) (pabyRec+psDBF->panFieldOffset[iField]),
            (char *) pValue, j );
        break;
    }

    return( nRetResult );
}


/************************************************************************/
/*                      DBFWriteIntegerAttribute()                      */
/*                                                                      */
/*      Write a integer attribute.                                      */
/************************************************************************/
int DBFWriteIntegerAttribute( DBFHandle psDBF, int iRecord, int iField,  int nValue )
{
    double      dValue = nValue;

    return( DBFWriteAttribute( psDBF, iRecord, iField, (void *) &dValue ) );
}
