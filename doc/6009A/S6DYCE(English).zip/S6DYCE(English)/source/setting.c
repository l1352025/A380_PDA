/*
 * setting.cpp
 *
 *  Created on: 2015��6��24��
 *      Author: iwork
 */
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <bios.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <io.h>
#include "setting.h"
#include "public.h"
#include "display.h"
