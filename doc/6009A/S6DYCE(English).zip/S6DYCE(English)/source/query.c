/*
 * operation.cpp
 *
 *  Created on: 2015��6��25��
 *      Author: iwork
 */
#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <bios.h> 
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <io.h>
#include "commplus.h"
#include "htxlcd.h"
#include "htlcd.h"
#include "infrared.h"
#include "query.h"
#include "display.h"
#include "public.h"

int               gCurrentItemSearchIndex;   //��ǰ��¼����� - ��ʾ��ǰ����
int               gCurrentItemSearchSum;     //�ܼ�¼��Ŀ - ��ʾ��ǰ����
CustomerInformation gCurrentCustomerInformation; //��ǰ�ͻ���Ϣ

UpdateInformation gUpdateInformation;

int LogFile_P;

Item_Display      gItemList[300];             //�����б�
int               gItemSum;                   //������Ŀͳ��

Item_Display      gCommunityList[10];        //С���б�
int               gCommunitySum;              //С����Ŀͳ��

Item_Display      gBuildingList[45];         //¥���б�
int               gBuildingSum;               //¥����Ŀͳ��


//ϵͳ��ʼ��
void GetCommunicationParameter(void)
{
	char iITEM[3];
    DBFHandle pDBF;
    //int tRecCount;
    unsigned char  iappdycd,iapptxxd,iapprxxd,ibootdycd,iboottxxd,ibootrxxd,iretrytime,iJZQDYCD,iJZQTXXD,iJZQRXXD;

	if(gDebugSwittchFlag==true)
	{				
		if((gFP=fopen("iTest","a+"))==NULL)
		{
			clrscr();
			printf("�޷��򿪵����ļ�!\n");
			getch();
			return;
		}
	}
	
	GetHT2900SerialNo(gLocalDeviceNo);
	AddZeroToFront(gLocalDeviceNo,12);  
	
    if(OpenDB(&pDBF,DBF_CONFIGURATION_FILENAME)==true)
    {
    	gBuildingSum = 0;
        //tRecCount=DBFGetRecordCount(pDBF);
        iappdycd=DBFGetFieldIndex(pDBF,"APPDYCD");
        iapptxxd=DBFGetFieldIndex(pDBF,"APPTXXD");
        iapprxxd=DBFGetFieldIndex(pDBF,"APPRXXD");
        ibootdycd=DBFGetFieldIndex(pDBF,"BOOTDYCD");
        iboottxxd=DBFGetFieldIndex(pDBF,"BOOTTXXD");
        ibootrxxd=DBFGetFieldIndex(pDBF,"BOOTRXXD");
        iretrytime=DBFGetFieldIndex(pDBF,"RETRYTIME");
		iJZQDYCD=DBFGetFieldIndex(pDBF,"JZQDYCD");
		iJZQTXXD=DBFGetFieldIndex(pDBF,"JZQTXXD");
		iJZQRXXD=DBFGetFieldIndex(pDBF,"JZQRXXD");
        {
			 //*********APP���Գ���*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iappdycd),2);
			 gAppDYCD =  HexStringToHEXValueInt(iITEM);
         }

         {                              //
			 //*********APP����ͨ���ŵ�*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iapptxxd),2);
			 gAppTXXD =  HexStringToHEXValueInt(iITEM);
         }

         {                              //
			 //*********APP����ͨ���ŵ�*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iapprxxd),2);
			 gAppRXXD =  HexStringToHEXValueInt(iITEM);
         }


         {
			 //*********BOOT���Գ���*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,ibootdycd),2);
			 gBootDYCD =  HexStringToHEXValueInt(iITEM);
         }

         {
			 //*********BOOT����ͨ���ŵ�*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iboottxxd),2);
			 gBootTXXD =  HexStringToHEXValueInt(iITEM);
         }

         {
			 //*********BOOT����ͨ���ŵ�*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,ibootrxxd),2);
			 gBootRXXD =  HexStringToHEXValueInt(iITEM);
         }

         {
			 //*********���˵��Գ���ͨ�Ŵ���*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iretrytime),1);
			 g0x72RetryTime =  HexStringToHEXValueInt(iITEM);
         }

         {
			 //*********���������Գ���*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iJZQDYCD),2);
			 gCollectorDYCD = HexStringToHEXValueInt(iITEM);
         }


         {
			 //*********����������ͨ���ŵ�*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iJZQTXXD),2);
			 gCollectorTXXD = HexStringToHEXValueInt(iITEM);
         }

         {
			 //*********����������ͨ���ŵ�*********//
			 memset(iITEM,0x00,sizeof(iITEM));
			 strncpy(iITEM,DBFReadStringAttribute(pDBF,0,iJZQRXXD),2);
			 gCollectorRXXD = HexStringToHEXValueInt(iITEM);
         }

		 	
/*  printf("gAppDYCD=%X,\n",gAppDYCD);                  //APP���Գ���
    printf("gAppTXXD=%X,\n",gAppTXXD);                  //APPͨ���ŵ�
    printf("gAppRXXD=%X,\n",gAppRXXD);                  //APPͨ���ŵ�
    printf("gBootDYCD=%X,\n",gBootDYCD);                //BOOT���Գ���
    printf("gBootTXXD=%X,\n",gBootTXXD);                //BOOTͨ���ŵ�
    printf("gBootRXXD=%X,\n",gBootRXXD);                //BOOTͨ���ŵ�
    printf("g0x72RetryTime=%X,\n",g0x72RetryTime);      //�㲥���ݰ�����
    printf("gCollectorDYCD=%X,\n",gCollectorDYCD);      //BOOT���Գ���
    printf("gCollectorTXXD=%X,\n",gCollectorTXXD);      //BOOTͨ���ŵ�
    printf("gCollectorRXXD=%X,\n",gCollectorRXXD);      //BOOTͨ���ŵ�  */
	
     	 CloseDB(&pDBF);
         return;
    }

}

//16�����ַ���ת����ʮ������ֵ
int HexStringToHEXValueInt(char iITEM[])
{
	int iHexValue=1,i=0,j=0;
	int n=0,IntValue=0,CalulationResult=0;

	n=strlen(iITEM);
	//printf("\n�����ַ�����%s,���ȣ�%d\n",iITEM,n);
	for(i=0;i<n;i++)
	{
		iHexValue=1;
		for(j=0;j<n-i-1;j++)
		{
			iHexValue = iHexValue*16;
		}

		{
			if((iITEM[i]>=0x30)&&(iITEM[i]<=0x39))
			{
				IntValue= (iITEM[i] - 48) + 0;
			}
			else if((iITEM[i]>='A')&&(iITEM[i]<='F'))
			{
				IntValue= (iITEM[i] - 'A') + 10;
			}
			else if((iITEM[i]>='a')&&(iITEM[i]<='f'))
			{
				IntValue= (iITEM[i] - 'a') + 10;
			}
		}

        //printf("\n��ǰ�ַ���%c\n",iITEM[i]);
        //printf("\n16����Ȩֵ��%d\n",iHexValue);

		CalulationResult = CalulationResult + IntValue*iHexValue;

	}
	return CalulationResult;
}


//�����ݿ�
bool OpenDB(DBFHandle *pDBF,const char * pszFilename)
{

	    /**
	    if (CheckBattHealth()==0x00) {
	    if (gLanguageFlag==ENGLISHLANGUAGE) {
	    printf("Low Power,\nAny Key Return...");
	    } else {
	    printf("��ص�ѹ���㣬\n�޷��洢���ݣ�\n�����������...\n");
	    }
	    getch();
	    return FALSE;
	    }
	    **/
	//ew_clear_client_area(true);
    //ew_display_string(16,16,(unsigned char*)"���ڴ�����...",COLOR_BLUE,0x10 | 1);
    *pDBF=OpenDBF(pszFilename,"rb+");
    if (*pDBF==NULL)
    {
    	clrscr();
		printf("�����ݿ����!\n");
		printf("�����������...\n");
        getch();
		return false ;
    }
    else
    {
    	return true;
    }
}

//�ر����ݿ�
void CloseDB(DBFHandle *pDBF)
{
    CloseDBF(*pDBF);
    return;
}

/******************************************************************************
** ��ȡ�����б� -- �򿪹ر����ݿ�
** ��������
** ����ֵ��TRUE�������ɹ���FALSE������ʧ�ܣ�
*****************************************************************************/
bool GetCommunityLish_FunApp(void )
{
    DBFHandle pDBF;
    int i,j,tRecCount;//,n
    unsigned char iCBYJFZMC;
    char sXQMC[61];//ttt[3];
    bool iRepeat=false;

    //CleanAll();
    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
    {

        gCommunitySum = 0;
        tRecCount=DBFGetRecordCount(pDBF);
        //iID=DBFGetFieldIndex(pDBF,"ID");
        iCBYJFZMC=DBFGetFieldIndex(pDBF,"CBYJFZMC");//С������
        //���ڲ�ѯ���ݿ�
    	clrscr();
#if Display_ENGLISH
        printf("Querying the database...\n");
#else
        printf("���ڲ�ѯ���ݿ�...\n");
#endif
        memset(gCommunityList,0x00,sizeof(gCommunityList));
        for (i=0;i<tRecCount;i++)
        {
            for (j=0;j<51;j++)
            {
                sXQMC[j]=0x20;
            	gCommunityList[gCommunitySum].Item_String[j]=0x20;
            }

           strncpy(sXQMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
           for (j=0;j<50;j++)
           {
               if(sXQMC[j]==0x20)
               {
            	   sXQMC[j]='\0';
            	   break;
               }
           }
//           sXQMC[50]='\0';
           // strcpy(sXQMC,"HelloWorld");
    	   //ew_display_string(32,(i+1)*16,(unsigned char* )sXQMC,COLOR_BLUE,0x10| 0x01);//


    	    if(iRepeat==true)
    	    {
    		    iRepeat = false;
    	    }

    	    for(j=0;j<gCommunitySum;j++)
    		{
    			if(strcmp(gCommunityList[j].Item_String,sXQMC)==0)
    			{
    				iRepeat = true;
    				break;
    			}
    		}

    	    if(iRepeat==false)
    	    {
    			strcpy(gCommunityList[gCommunitySum].Item_String,sXQMC);
    			gCommunityList[gCommunitySum].Item_Index = i;
    			gCommunitySum++;
    	    }

        }

    	CloseDB(&pDBF);
    	return true;
    }
    else
    {
    	return false;
    }
}

/*
* ��ȡ¥���б� -- �򿪹ر����ݿ�
* ������
*      iType     0:����С��ѡ��¥��      1��ȫ��¥����ѯ   
* ����ֵ��TRUE�������ɹ���FALSE������ʧ�ܣ�
*/
bool GetBuildingLish_FunApp(unsigned char iType )
{
    DBFHandle pDBF;
    int i,j,tRecCount;
    unsigned char iCBYJFZMC,iCBEJFZMC;  // iID,
    char sXQMC[51],sLDMC[51];
    bool iRepeat=false;

    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
    {
		
		//���ڲ�ѯ���ݿ�
    	clrscr();
#if Display_ENGLISH
        printf("Querying the database...\n");
#else
        printf("���ڲ�ѯ���ݿ�...\n");  
#endif		
    	gBuildingSum = 0;
        tRecCount=DBFGetRecordCount(pDBF);
        //iID=DBFGetFieldIndex(pDBF,"ID");
        iCBYJFZMC=DBFGetFieldIndex(pDBF,"CBYJFZMC");//С������
        iCBEJFZMC=DBFGetFieldIndex(pDBF,"CBEJFZMC");//¥������

        for (i=0;i<tRecCount;i++)
        {
    		for (j=0;j<51;j++)
    		{
    			sXQMC[j]=0x20;
    			sLDMC[j]=0x20;
    			gBuildingList[gBuildingSum].Item_String[j]=0x20;
    		}

    		//*********ͬһ��С��*********//
            strncpy(sXQMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
    		for (j=0;j<50;j++)
    		{
    			if(sXQMC[j]==0x20)
    			{
    				sXQMC[j]='\0';
    				break;
    			}
    		}

            if(iType == 0x01) //ȫ��©��ͳ��   
            {
                strcpy(gCommunityName,sXQMC);
            }

    		if(strcmp(gCommunityName,sXQMC)==0)
    		{
    			//ew_display_string(32,64,(unsigned char* )"HelloWorld",COLOR_BLUE,0x10| 0x01);//

                //��ȡ¥������
                strncpy(sLDMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
        		for (j=0;j<50;j++)
        		{
        			if(sLDMC[j]==0x20)
        			{
        				sLDMC[j]='\0';
        				break;
        			}
        		}

                iRepeat = false;
    			for(j=0;j<gBuildingSum;j++)
    			{
    				if(strcmp(gBuildingList[j].Item_String,sLDMC)==0)
    				{
    					iRepeat=true;
    				}
    			}
    			if(iRepeat==false)
    			{
    				strcpy(gBuildingList[gBuildingSum].Item_String,sLDMC);
    				gBuildingList[gBuildingSum].Item_Index = i;
    				gBuildingSum++;
    			}
    		}

        }
    	CloseDB(&pDBF);
        return true;
    }
    else
    {
    	return false;
    }
}

/******************************************************************************
** ��ȡ¥���б�
** ������
**      pDBF�����ݿ�ָ��
**      sFlag����ѯ�б�״̬��'0'--δ��    '1'--�ѳ�     '2'--ʧ��    '3'--ȫ����
** ����ֵ��
**     ��
*****************************************************************************/
bool RecordSearch_FunApp( char sFlag, char DisplayType )
{
    DBFHandle pDBF;
    int i,j,tRecCount;
    bool iMeterNoNormalFlag = true;
    unsigned char MeterJudgement[BH_Length+1];
    unsigned char  iCBYJFZMC,iCBEJFZMC,iCBZT,iBH,iHM,iHH,iMPH,iDZ;
    char sXQMC[51],sLDMC[51],sCBZT[2],sMPH[MPH_Length+1],FlagString[2],sBH[BH_Length+1],sDZ[DZ_Length+1],sHM[HM_Length+1],sHH[HH_Length+1];

    if (gDebugSwittchFlag)
    {
        unsigned char  iTimeString[50]={0x00};
        unsigned char  iTestString[50]={0x00};
        
        fputs("\n?---------------------------------------------------------------\n",gFP);

        memset(iTimeString,0x00,sizeof(iTimeString));
        GetSystemTime_New(iTimeString); 
        strcat(iTimeString,"\n");                   
        fputs(iTimeString,gFP);
        
        memset(iTestString,0x00,sizeof(iTestString));
        sprintf(iTestString,"�����Զ�����ģʽ�������ݿ�");
        fputs(iTestString,gFP);

        fputs("\n?---------------------------------------------------------------\n",gFP);
    }


	if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
	{
		gItemSum = 0;
        memset(gItemList,0x00,sizeof(gItemList));
	    tRecCount=DBFGetRecordCount(pDBF);
	    //iID=DBFGetFieldIndex(pDBF,"ID");
	    iCBYJFZMC=DBFGetFieldIndex(pDBF,"CBYJFZMC");//С������
	    iCBEJFZMC=DBFGetFieldIndex(pDBF,"CBEJFZMC");//¥������
	    iCBZT=DBFGetFieldIndex(pDBF,"CBZT");//����״̬
	    iMPH=DBFGetFieldIndex(pDBF,"MPH");//���ƺ�
	    iBH=DBFGetFieldIndex(pDBF,"BH");//����
	    iHM=DBFGetFieldIndex(pDBF,"HM");//����
	    iHH=DBFGetFieldIndex(pDBF,"HH");//����
	    iDZ=DBFGetFieldIndex(pDBF,"DZ");//��ַ
	    if (gDebugSwittchFlag)
        {
            unsigned char  iTimeString[50]={0x00};
            unsigned char  iTestString[50]={0x00};
            fputs("\n?---------------------------------------------------------------\n",gFP);
#if 0					
			 memset(iTimeString,0x00,sizeof(iTimeString));
			 GetSystemTime_New(iTimeString); 
			 strcat(iTimeString,"\n");					 
			 fputs(iTimeString,gFP);	
			
			 for(i=0;i<100;i++)
			 {
				memset(iTestString,0x00,sizeof(iTestString));
				sprintf(iTestString,",%X%X",gMemoryString[i]>>4,gMemoryString[i]&0x0F);
				fputs(iTestString,gFP);
			 }
#endif          
            memset(iTimeString,0x00,sizeof(iTimeString));
            GetSystemTime_New(iTimeString); 
            strcat(iTimeString,"\n");                   
            fputs(iTimeString,gFP);
            
            memset(iTestString,0x00,sizeof(iTestString));
            sprintf(iTestString,"tRecCount = %d",tRecCount);
            fputs(iTestString,gFP);
            
			fputs("\?---------------------------------------------------------------\n",gFP);
        }   

	    for (i=0;i<tRecCount;i++)
	    {

			for (j=0;j<51;j++)
			{
				sXQMC[j]=0x20;
				sLDMC[j]=0x20;
				gBuildingList[gBuildingSum].Item_String[j]=0x20;
			}

			//*********ͬһ��С��*********//
	        strncpy(sXQMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
    		for (j=0;j<50;j++)
    		{
    			if(sXQMC[j]==0x20)
    			{
    				sXQMC[j]='\0';
    				break;
    			}
    		}

			if(strcmp(gCommunityName,sXQMC)==0)
			{
	            //��ȡ¥������
	            strncpy(sLDMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
	    		for (j=0;j<50;j++)
	    		{
	    			if(sLDMC[j]==0x20)
	    			{
	    				sLDMC[j]='\0';
	    				break;
	    			}
	    		}


				if(strcmp(gBuildingName,sLDMC)==0)
				{

		            //��ȡ¥������
		            strncpy(sCBZT,DBFReadStringAttribute(pDBF,i,iCBZT),1);
		            sCBZT[1]='\0';

		            //ȫ����¼
	                if(sFlag==0x32)
					{
						sCBZT[0] = 0x32;
					}
		            FlagString[0]=sFlag;
		            FlagString[1]='\0';

		            if(strcmp(sCBZT,FlagString)==0)
		            {

		            	if(gReturnNow==true)
		            	{
							//////�Զ������쳣���Ŵ�����
							iMeterNoNormalFlag = true;
	//						if(strlen(DBFReadStringAttribute(pDBF,i,iBH))>10)
	//						{
	//							iMeterNoNormalFlag=false;
	//						}
	//						else
	//						{
								memset(MeterJudgement,0x00,BH_Length+1);
								memcpy(MeterJudgement,DBFReadStringAttribute(pDBF,i,iBH),BH_Length);
								for(j=0;j<BH_Length;j++)
								{
									if((MeterJudgement[j]>0x39)||(MeterJudgement[j]<0x30))
									{
										iMeterNoNormalFlag=false;
									}
								}
	//						}

							if(iMeterNoNormalFlag==false)
							{
								continue;
							}
		            	}
			            //����
			            strncpy(sBH,DBFReadStringAttribute(pDBF,i,iBH),BH_Length);
			            sBH[BH_Length]='\0';
			            strcpy(gItemList[gItemSum].MeterNo_String,sBH);

						switch(DisplayType)
						{
						case 0://����
	                        memset(sHM,0x20,HM_Length);
				            strncpy(sHM,DBFReadStringAttribute(pDBF,i,iHM),HM_Length);
				    		for (j=0;j<HM_Length+1;j++)
				    		{
				    			if(sHM[j]==0x20)
				    			{
				    				sHM[j]='\0';
				    				break;
				    			}
				    		}

							//��ȡѡ�еļ�¼����
							if(strlen(sHM)<25)
							{
								strcat(sHM,"                           ");
							}
							sHM[22]=' ';
							if(sFlag==0x30)
							{
								sHM[23]='N';
							}
							else if(sFlag==0x31)
							{
								sHM[23]='Y';
							}
							else if(sFlag==0x0032)
							{
								sHM[23]='F'; //ʧ����F   �ѳ�Y   δ��N
							}
							sHM[24]='\0';

							strcpy(gItemList[gItemSum].Item_String,sHM);


				            //��ȡ��ַ
	                        memset(sDZ,0x20,DZ_Length);
				            strncpy(sDZ,DBFReadStringAttribute(pDBF,i,iDZ),DZ_Length);
				    		for (j=0;j<DZ_Length+1;j++)
				    		{
				    			if(sDZ[j]==0x20)
				    			{
				    				sDZ[j]='\0';
				    				break;
				    			}
				    		}
//
//							//��ȡѡ�еļ�¼����
//							if(strlen(sDZ)<25)
//							{
//								strcat(sDZ,"                           ");
//							}
//							sDZ[22]=' ';
//							if(sFlag==0x30)
//							{
//								sDZ[23]='N';
//							}
//							else if(sFlag==0x31)
//							{
//								sDZ[23]='Y';
//							}
//							else if(sFlag==0x0032)
//							{
//								sDZ[23]='F'; //ʧ����F   �ѳ�Y   δ��N
//							}
//							sDZ[24]='\0';

							strcpy(gItemList[gItemSum].Item_OtherString,sDZ);
							break;
						case 1://����
	                        memset(sHM,0x20,MPH_Length);
				            strncpy(sHM,DBFReadStringAttribute(pDBF,i,iHM),MPH_Length);
				    		for (j=0;j<MPH_Length+1;j++)
				    		{
				    			if(sHM[j]==0x20)
				    			{
				    				sHM[j]='\0';
				    				break;
				    			}
				    		}

							//��ȡѡ�еļ�¼����
							if(strlen(sHM)<25)
							{
								strcat(sHM,"                           ");
							}
							sHM[22]=' ';
							if(sFlag==0x30)
							{
								sHM[23]='N';
							}
							else if(sFlag==0x31)
							{
								sHM[23]='Y';
							}
							else if(sFlag==0x0032)
							{
								sHM[23]='F'; //ʧ����F   �ѳ�Y   δ��N
							}
							sHM[24]='\0';

							strcpy(gItemList[gItemSum].Item_String,sHM);
							break;
						case 2://����
	                        memset(sHH,0x20,HH_Length);
				            strncpy(sHH,DBFReadStringAttribute(pDBF,i,iHH),HH_Length);
				    		for (j=0;j<HH_Length+1;j++)
				    		{
				    			if(sHH[j]==0x20)
				    			{
				    				sHH[j]='\0';
				    				break;
				    			}
				    		}

							//��ȡѡ�еļ�¼����
							if(strlen(sHH)<25)
							{
								strcat(sHH,"                           ");
							}
							sHH[22]=' ';
							if(sFlag==0x30)
							{
								sHH[23]='N';
							}
							else if(sFlag==0x31)
							{
								sHH[23]='Y';
							}
							else if(sFlag==0x0032)
							{
								sHH[23]='F'; //ʧ����F   �ѳ�Y   δ��N
							}
							sHH[24]='\0';


							strcpy(gItemList[gItemSum].Item_String,sHH);
							break;
						case 3://���ƺ�
	                        memset(sMPH,0x20,MPH_Length);
				            strncpy(sMPH,DBFReadStringAttribute(pDBF,i,iMPH),MPH_Length);
				    		for (j=0;j<MPH_Length+1;j++)
				    		{
				    			if(sMPH[j]==0x20)
				    			{
				    				sMPH[j]='\0';
				    				break;
				    			}
				    		}


							//��ȡѡ�еļ�¼����
							if(strlen(sMPH)<25)
							{
								strcat(sMPH,"                           ");
							}
							sMPH[22]=' ';
							if(sFlag==0x30)
							{
								sMPH[23]='N';
							}
							else if(sFlag==0x31)
							{
								sMPH[23]='Y';
							}
							else if(sFlag==0x0032)
							{
								sMPH[23]='F'; //ʧ����F   �ѳ�Y   δ��N
							}
							sMPH[24]='\0';



							strcpy(gItemList[gItemSum].Item_String,sMPH);
							break;
						case 4://��ַ
				            //��ȡ���ƺ�����
	                        memset(sDZ,0x20,DZ_Length);
				            strncpy(sDZ,DBFReadStringAttribute(pDBF,i,iDZ),DZ_Length);
				    		for (j=0;j<DZ_Length+1;j++)
				    		{
				    			if(sDZ[j]==0x20)
				    			{
				    				sDZ[j]='\0';
				    				break;
				    			}
				    		}

							//��ȡѡ�еļ�¼����
							if(strlen(sDZ)<25)
							{
								strcat(sDZ,"                           ");
							}
							sDZ[22]=' ';
							if(sFlag==0x30)
							{
								sDZ[23]='N';
							}
							else if(sFlag==0x31)
							{
								sDZ[23]='Y';
							}
							else if(sFlag==0x0032)
							{
								sDZ[23]='F'; //ʧ����F   �ѳ�Y   δ��N
							}
							sDZ[24]='\0';


							strcpy(gItemList[gItemSum].Item_String,sDZ);
							break;
						}
						gItemList[gItemSum].Item_Index = i;
						gItemSum++;
		            }


				}

			}

	    }

		CloseDB(&pDBF);
		return true;
	}
	else
	{
		return false;
	}

}

/******************************************************************************
** ���泭�����ݵ����ݿ�
** ������
**      pDBF�����ݿ�ָ��
**      sFlag����ѯ�б�״̬��'0'--δ��    '1'--�ѳ�     '2'--ʧ��    '3'--ȫ����
** ����ֵ��
**     ��
*****************************************************************************/
void SaveDataToDB_FunApp(void)
{ //void SaveDataToDB_FunApp()
    DBFHandle pDBF;
	char displaystring[50]={0x00};   
    int tRecCount;// j,i iBH,
    unsigned char iFLA,iCBSJ,iCBZT,iBZTHEX,iBZTSTR,iXHQD,iCSFS,iCBDY;
    char MeterValueString[20]={0},BZTSTRString[51]={0}; //sFLA[12],  sBH[12],

	//�洢��������-3 
	if(gDebugSwittchFlag==true)
	{
		memset(displaystring,0x00,sizeof(displaystring));     
		sprintf(displaystring,"�洢�û���������%d\n",gCurrentCustomerInformation.SearchIndex);
		fputs(displaystring,gFP);	      				
	}
	
    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
    {
        tRecCount=DBFGetRecordCount(pDBF);

		if(gCurrentCustomerInformation.SearchIndex>tRecCount)
		{
			CloseDBF(pDBF);
		    return;
		}

        //iBH=DBFGetFieldIndex(pDBF,"BH"); //����
        iFLA=DBFGetFieldIndex(pDBF,"FLA");//������
        iCBSJ=DBFGetFieldIndex(pDBF,"CBSJ");//����ʱ��
        iCBZT=DBFGetFieldIndex(pDBF,"CBZT");//����״̬
        iBZTHEX=DBFGetFieldIndex(pDBF,"BZTHEX");//��״̬HEX
		iBZTSTR=DBFGetFieldIndex(pDBF,"BZTSTR");//��״̬STR
		iXHQD=DBFGetFieldIndex(pDBF,"XHQD");//�ź�ǿ��
		iCSFS=DBFGetFieldIndex(pDBF,"SGCQ");//������ʽ
		iCBDY=DBFGetFieldIndex(pDBF,"DCDY");//������ѹ


        //////��������
		sprintf(MeterValueString,"%.0f",gCurrentCustomerInformation.MeterReadingDouble);
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iFLA,MeterValueString);
		//////����״̬
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iCBZT,gCurrentCustomerInformation.CBZTString);
        //////����ʱ��
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iCBSJ,gCurrentCustomerInformation.CBSJString);
        //////��״̬HEX
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iBZTHEX,gCurrentCustomerInformation.MeterStateHEX);
		//////��״̬STR
		strncpy(BZTSTRString,gCurrentCustomerInformation.MeterStateSTR,50);
		BZTSTRString[51]='\0';
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iBZTSTR,BZTSTRString);        
        //////�ź�ǿ��-�����洢
		DBFWriteIntegerAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iXHQD,gCurrentCustomerInformation.ReadSignalIntensity);
		//////������ѹ
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iCBDY,gCurrentCustomerInformation.DCDYString);
		//////������ʽ
		DBFWriteStringAttribute(pDBF,gCurrentCustomerInformation.SearchIndex,iCSFS,gCurrentCustomerInformation.MeterReadMethod);

		CloseDB(&pDBF);
		return;
	}
	else
	{
		 return;
	}

}

/******************************************************************************
** ȫ������ͳ��
** ������ StatisticsType��ͳ������   '0'--ȫ��    '1'--С��    '2'--¥��     '3'--С����¥����
** ����ֵ��TRUE�������ɹ���FALSE������ʧ�ܣ�
*****************************************************************************/
bool StatisticsCalculation_FunApp(int *WC_Sum, int *YC_Sum,int StatisticsType)
{
    DBFHandle pDBF;  //
    int i,tRecCount,iCBZT,iCBYJFZMC,iCBEJFZMC,j;
    char sCBZT[5],sCBYJFZMC[51],sCBEJFZMC[51]; //sFLA[12],

    *YC_Sum = 0;
    *WC_Sum = 0;
    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
    {
        tRecCount=DBFGetRecordCount(pDBF);
        iCBYJFZMC=DBFGetFieldIndex(pDBF,"CBYJFZMC");
        iCBEJFZMC=DBFGetFieldIndex(pDBF,"CBEJFZMC");
        iCBZT=DBFGetFieldIndex(pDBF,"CBZT");

        for(i=0;i<tRecCount;i++)
        {
        	if(StatisticsType==0)
        	{
            	//��ȡ����״̬
                strncpy(sCBZT,DBFReadStringAttribute(pDBF,i,iCBZT),2);
                sCBZT[1]='\0';
                if(strcmp(sCBZT,"1")==0)
                {
                	(*YC_Sum)++;
                }
                else
                {
                	(*WC_Sum)++;
                }
        	}
        	else if(StatisticsType==1)
        	{
            	//��ȡС������
        		memset(sCBYJFZMC,0x20,51);
                strncpy(sCBYJFZMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
                for(j=0;j<51;j++)
                {
					if(sCBYJFZMC[j]==0x20)
					{
						sCBYJFZMC[j]='\0';
						break;
					}
                }
                if(strcmp(sCBYJFZMC,gCommunityName)==0)
                {
                	//��ȡС���û��ĳ���״̬
                    strncpy(sCBZT,DBFReadStringAttribute(pDBF,i,iCBZT),2);
                    sCBZT[1]='\0';
                    if(strcmp(sCBZT,"1")==0)
                    {
                    	(*YC_Sum)++;
                    }
                    else
                    {
                    	(*WC_Sum)++;
                    }

                }
        	}
        	else if(StatisticsType==2)
        	{
            	//��ȡ¥������
        		memset(sCBEJFZMC,0x20,51);
                strncpy(sCBEJFZMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
                for(j=0;j<51;j++)
                {
					if(sCBEJFZMC[j]==0x20)
					{
						sCBEJFZMC[j]='\0';
					}
                }
                if(strcmp(sCBEJFZMC,gBuildingName)==0)
                {
                	//��ȡС���û��ĳ���״̬
                    strncpy(sCBZT,DBFReadStringAttribute(pDBF,i,iCBZT),2);
                    sCBZT[1]='\0';
                    if(strcmp(sCBZT,"1")==0)
                    {
                    	(*YC_Sum)++;
                    }
                    else
                    {
                    	(*WC_Sum)++;
                    }

                }
        	}
        	else if(StatisticsType==3)
        	{
            	//��ȡС������
        		memset(sCBYJFZMC,0x20,51);
                strncpy(sCBYJFZMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
                for(j=0;j<51;j++)
                {
					if(sCBYJFZMC[j]==0x20)
					{
						sCBYJFZMC[j]='\0';
						break;
					}
                }
            	//��ȡ¥������
            	memset(sCBEJFZMC,0x20,51);
                strncpy(sCBEJFZMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
                for(j=0;j<51;j++)
                {
					if(sCBEJFZMC[j]==0x20)
					{
						sCBEJFZMC[j]='\0';
						break;
					}
                }

                if((strcmp(sCBYJFZMC,gCommunityName)==0)&&(strcmp(sCBEJFZMC,gBuildingName)==0))
                {
                	//��ȡС���û��ĳ���״̬
                    strncpy(sCBZT,DBFReadStringAttribute(pDBF,i,iCBZT),2);
                    sCBZT[1]='\0';
                    if(strcmp(sCBZT,"1")==0)
                    {
                    	(*YC_Sum)++;
                    }
                    else
                    {
                    	(*WC_Sum)++;
                    }

                }
        	}
        	else
        	{
        		CloseDB(&pDBF);
        		 return false;
        	}

        }

		CloseDB(&pDBF);
		return true;
    }
	else
	{
		 return false;
	}
}

/******************************************************************************
** ��ѯ
** ������ sFlag����ѯ�б�״̬��'0'--δ��    '1'--�ѳ�    '2'--ȫ����
** ����ֵ��TRUE�������ɹ���FALSE������ʧ�ܣ�
*****************************************************************************/
bool CustomerInfoSearch_FunApp(int SearchType)
{
    DBFHandle pDBF;
    int i,j,tRecCount,iCBYJFZMC,iCBEJFZMC,iBH,iMPH,iHH;     
    char sCBYJFZMC[51]={0x20},sCBEJFZMC[51]={0x20},sBH[BH_Length+1]={0x20},sMPH[MPH_Length+1]={0x20},sHH[HH_Length+1]={0x20};//DisplayString[101]={0}; //sFLA[12],

    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
    {
//    	ew_clear_client_area(true);
//     	ew_display_string(16,16,(unsigned char*)"���ڲ�ѯ���ݿ�...",COLOR_BLUE,0x10);//
//     	ew_updata_display();
        tRecCount=DBFGetRecordCount(pDBF);
        iBH=DBFGetFieldIndex(pDBF,"BH");
        iMPH=DBFGetFieldIndex(pDBF,"MPH");
        iHH=DBFGetFieldIndex(pDBF,"HH");

//        ew_clear_client_area(true);
//		sprintf(DisplayString,"�ܹ�%d����¼!",tRecCount);
//		ew_display_string(16,48,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//		ew_display_string(16,16,(unsigned char*)"���ڲ�ѯ���ݿ�...",COLOR_BLUE,0x10);//
//		ew_updata_display();

		if(SearchType==1)//�����Ų�ѯ
		{
			for(i=0;i<tRecCount;i++)
			{
				//������ʾ
//				ew_screen_paint_line(80, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//				sprintf(DisplayString,"���ڲ�ѯ��%d����¼!",i);
//				ew_display_string(16,80,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//				ew_updata_display();
				//��ȡС������
				memset(sBH,0x20,sizeof(sBH));   
				strncpy(sBH,DBFReadStringAttribute(pDBF,i,iBH),BH_Length);
				sBH[BH_Length]='\0';
				if(strcmp(sBH,gCurrentCustomerInformation.BHString)==0)
				{
					gCurrentCustomerInformation.SearchIndex = i;
					CloseDB(&pDBF);
                    return true;
				}
			}
		   //û�ҵ�
			CloseDB(&pDBF);
		   return false;
		}
		else if(SearchType==2)//�����Ų�ѯ
		{
			for(i=0;i<tRecCount;i++)
			{
				//������ʾ
//				ew_screen_paint_line(80, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//				sprintf(DisplayString,"���ڲ�ѯ��%d����¼!",i);
//				ew_display_string(16,80,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//				ew_updata_display();
				//��ȡС������
				memset(sHH,0x20,sizeof(sHH));      
				strncpy(sHH,DBFReadStringAttribute(pDBF,i,iHH),HH_Length);
				for(j=HH_Length;j>0;j--)
				{
					if(sHH[j-1]!=0x20)
					{
						sHH[j]='\0';
						break;
					}
				}

				if(strcmp(sHH,gCurrentCustomerInformation.HHString)==0)
				{
					gCurrentCustomerInformation.SearchIndex = i;
					CloseDB(&pDBF);
                    return true;
				}
			}

		   //û�ҵ�
			CloseDB(&pDBF);
		   return false;
		}
		else if(SearchType==3)//�����ƺŲ�ѯ
		{
			for(i=0;i<tRecCount;i++)
			{
				//������ʾ
//				ew_screen_paint_line(80, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//				sprintf(DisplayString,"���ڲ�ѯ��%d����¼!",i);
//				ew_display_string(16,80,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//				ew_updata_display();
				//��ȡС������
				memset(sMPH,0x20,sizeof(sMPH));    
				strncpy(sMPH,DBFReadStringAttribute(pDBF,i,iMPH),MPH_Length);
				for(j=0;j<MPH_Length;j++)
				{
					if(sMPH[j]==0x20)
					{
						sMPH[j]='\0';
						break;
					}
				}
//
//printf("��������ƺţ�%s\n",gMPHName);
//printf("���ҵ������ƺţ�%s\n",sMPH);
//getch();
				if(strcmp(sMPH,gCurrentCustomerInformation.MPHString)==0)
				{
					gCurrentCustomerInformation.SearchIndex = i;
					CloseDB(&pDBF);
                    return true;
				}
			}

		   //û�ҵ�
			CloseDB(&pDBF);
		   return false;
		}
		else if(SearchType==4)//�����ų���
		{
			for(i=0;i<tRecCount;i++)
			{
				//������ʾ
//				ew_screen_paint_line(80, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//				sprintf(DisplayString,"���ڲ�ѯ��%d����¼!",i);
//				ew_display_string(16,80,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//				ew_updata_display();
				//�Ƚ� С������  ¥������  ���ƺ�����
				memset(sCBYJFZMC,0x20,sizeof(sCBYJFZMC));
				strncpy(sCBYJFZMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
				for(j=0;j<50;j++)
				{
					if(sCBYJFZMC[j]==0x20)
					{
						sCBYJFZMC[j]='\0';
						break;
					}
				}
				
				memset(sCBEJFZMC,0x20,sizeof(sCBEJFZMC));
				strncpy(sCBEJFZMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
				for(j=0;j<50;j++)
				{
					if(sCBEJFZMC[j]==0x20)
					{
						sCBEJFZMC[j]='\0';
						break;
					}
				}

				memset(sBH,0x20,sizeof(sBH));   
				strncpy(sBH,DBFReadStringAttribute(pDBF,i,iBH),BH_Length);
				for(j=0;j<BH_Length;j++)
				{
					if(sBH[j]==0x20)
					{
						sBH[j]='\0';
						break;
					}
				}


				if((strcmp(sCBYJFZMC,gCommunityName)==0)&&(strcmp(sCBEJFZMC,gBuildingName)==0)&&(strcmp(sBH,gCurrentCustomerInformation.BHString)==0))
				{
					gCurrentCustomerInformation.SearchIndex = i;
					CloseDB(&pDBF);
                    return true;
				}
			}

		   //û�ҵ�
			CloseDB(&pDBF);
		   return false;
		}
		else if(SearchType==5)//�����ų���   
		{
			for(i=0;i<tRecCount;i++)
			{
				//������ʾ
//				ew_screen_paint_line(80, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//				sprintf(DisplayString,"���ڲ�ѯ��%d����¼!",i);
//				ew_display_string(16,80,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//				ew_updata_display();
				//�Ƚ� С������  ¥������  ���ƺ�����
				memset(sCBYJFZMC,0x20,sizeof(sCBYJFZMC)); 
				strncpy(sCBYJFZMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
				for(j=0;j<50;j++)
				{
					if(sCBYJFZMC[j]==0x20)
					{
						sCBYJFZMC[j]='\0';
						break;
					}
				}

				memset(sCBEJFZMC,0x20,sizeof(sCBEJFZMC));   
				strncpy(sCBEJFZMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
				for(j=0;j<50;j++)
				{
					if(sCBEJFZMC[j]==0x20)
					{
						sCBEJFZMC[j]='\0';
						break;
					}
				}

				//��ȡС������
				memset(sHH,0x20,sizeof(sHH)); 
				strncpy(sHH,DBFReadStringAttribute(pDBF,i,iHH),HH_Length);
				for(j=0;j<HH_Length;j++)
				{
					if(sHH[j]==0x20)
					{
						sHH[j]='\0';
						break;
					}
				}

				if((strcmp(sCBYJFZMC,gCommunityName)==0)&&(strcmp(sCBEJFZMC,gBuildingName)==0)&&(strcmp(sHH,gCurrentCustomerInformation.HHString)==0))
				{
					gCurrentCustomerInformation.SearchIndex = i;
					CloseDB(&pDBF);
                    return true;
				}
			}

		   //û�ҵ�
			CloseDB(&pDBF);
		   return false;
		}
		else if(SearchType==6)//�����ƺų���
		{
			for(i=0;i<tRecCount;i++)
			{
				//������ʾ
//				ew_screen_paint_line(80, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//				sprintf(DisplayString,"���ڲ�ѯ��%d����¼!",i);
//				ew_display_string(16,80,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//				ew_updata_display();
				//�Ƚ� С������  ¥������  ���ƺ�����
				memset(sCBYJFZMC,0x20,sizeof(sCBYJFZMC)); 
				strncpy(sCBYJFZMC,DBFReadStringAttribute(pDBF,i,iCBYJFZMC),50);
				for(j=0;j<50;j++)
				{
					if(sCBYJFZMC[j]==0x20)
					{
						sCBYJFZMC[j]='\0';
						break;
					}
				}

				memset(sCBEJFZMC,0x20,sizeof(sCBEJFZMC)); 
				strncpy(sCBEJFZMC,DBFReadStringAttribute(pDBF,i,iCBEJFZMC),50);
				for(j=0;j<50;j++)
				{
					if(sCBEJFZMC[j]==0x20)
					{
						sCBEJFZMC[j]='\0';
						break;
					}
				}


				//��ȡС������
				memset(sMPH,0x20,sizeof(sMPH));   
				strncpy(sMPH,DBFReadStringAttribute(pDBF,i,iMPH),MPH_Length);
				for(j=0;j<MPH_Length;j++)
				{
					if(sMPH[j]==0x20)     
					{
						sMPH[j]='\0';
						break;
					}
				}

				if((strcmp(sCBYJFZMC,gCommunityName)==0)&&(strcmp(sCBEJFZMC,gBuildingName)==0)&&(strcmp(sMPH,gCurrentCustomerInformation.MPHString)==0))
				{
					gCurrentCustomerInformation.SearchIndex = i;
					CloseDB(&pDBF);
                    return true;
				}
			}

		   //û�ҵ�
			CloseDB(&pDBF);
		   return false;
		}
		else
		{
			CloseDB(&pDBF);
			return false;
		}
//    else if()
//    {
//
//    }
    }
	else
	{
		 //���ݿ��ʧ��
		 return false;
	}
}
/*     
* ���ܣ������������ҵ�ǰ�û���Ϣ 
* ������
*      SearchIndex:  ��ѯ����  
*      iCollectorType: ��������������  0:ֱ�ӶԱ�����  1�������������   2�������������� 
*/
bool GetCustomerInformation(int SearchIndex,unsigned char iCollectorType)
{
	int j=0,tRecCount=0;
	unsigned char MeterJudgement[BH_Length+1];
	DBFHandle pDBF;  //
	char displaystring[50]={0x00};   
    int iHH,iHM,iDZ,iMOBILE,iMPH,iBH,iFLA,iCBSJ,iCBZT,iSGCQ,iDCDY,iBZTSTR,iBZTHEX,iXHQD,iZDBH;
   // char sHH[33],sHM[51],sDZ[101],sTEL[21],sMPH[17],sBH[13],sFLA[13],sCBSJ[21],sCBZT[2];

//    tRecCount=DBFGetRecordCount(pDBF);   
	//�洢��������-2 
	if(gDebugSwittchFlag==true)
	{
		memset(displaystring,0x00,sizeof(displaystring));    
		sprintf(displaystring,"��ѯ�û���Ϣ������%d\n",gCurrentCustomerInformation.SearchIndex);
		fputs(displaystring,gFP);	      				
	}
    //ew_display_string(16,16,(unsigned char*)"���ڴ�����...",COLOR_BLUE,0x10 | 1);
    pDBF=OpenDBF(DBF_DATABASE_FILENAME,"rb+");
    if (pDBF==NULL)
    {
    	clrscr();
		printf("�����ݿ����!\n");
		printf("�����������...\n");
        getch();
        CloseDBF(pDBF);
		return false ;
    }

    tRecCount=DBFGetRecordCount(pDBF);
	if(SearchIndex>tRecCount)
	{
		CloseDBF(pDBF);
	   return false;
	}
    iHH=DBFGetFieldIndex(pDBF,"HH");
    iHM=DBFGetFieldIndex(pDBF,"HM");
    iDZ=DBFGetFieldIndex(pDBF,"DZ");
    iMOBILE=DBFGetFieldIndex(pDBF,"MOBILE");
    iMPH=DBFGetFieldIndex(pDBF,"MPH");
    iBH=DBFGetFieldIndex(pDBF,"BH");
    iFLA=DBFGetFieldIndex(pDBF,"FLA");//������
    iCBSJ=DBFGetFieldIndex(pDBF,"CBSJ");
    iCBZT=DBFGetFieldIndex(pDBF,"CBZT");
    iSGCQ=DBFGetFieldIndex(pDBF,"SGCQ");
    iDCDY=DBFGetFieldIndex(pDBF,"DCDY");
    iBZTSTR=DBFGetFieldIndex(pDBF,"BZTSTR");
    iBZTHEX=DBFGetFieldIndex(pDBF,"BZTHEX");
	iXHQD=DBFGetFieldIndex(pDBF,"XHQD");  
	

    //if(OpenDB(&pDBF)==true)
    {

		//����쳣����
        gCurrentCustomerInformation.MeterNoNormalFlag=true;
//		if(strlen(DBFReadStringAttribute(pDBF,SearchIndex,iBH))>10)
//		{
//			ew_clear_client_area(true);
//			ew_display_string(1,48,(unsigned char*)gCurrentCustomerInformation.BHString,COLOR_BLUE,0x10);
//			ew_display_string(1,96,(unsigned char*)"���Ŵ���10��",COLOR_BLUE,0x10);
//			ew_updata_display();
//			getch();
//			gCurrentCustomerInformation.MeterNoNormalFlag=false;
//		}
//		else
//		{
			memset(MeterJudgement,0x00,BH_Length+1);
			memcpy(MeterJudgement,DBFReadStringAttribute(pDBF,SearchIndex,iBH),BH_Length);
			for(j=0;j<BH_Length;j++)
			{
				if((MeterJudgement[j]>0x39)||(MeterJudgement[j]<0x30))
				{
					gCurrentCustomerInformation.MeterNoNormalFlag=false;
				}
			}
//		}

	   //��ʾ����
	   memset(gCurrentCustomerInformation.BHString,0x00,sizeof(gCurrentCustomerInformation.BHString));
	   strncpy(gCurrentCustomerInformation.BHString,DBFReadStringAttribute(pDBF,SearchIndex,iBH),BH_Length);
	   gCurrentCustomerInformation.BHString[BH_Length]='\0';

	   memset(gCurrentCustomerInformation.HHString,0x20,sizeof(gCurrentCustomerInformation.HHString));
	   strncpy(gCurrentCustomerInformation.HHString,DBFReadStringAttribute(pDBF,SearchIndex,iHH),HH_Length);
	   gCurrentCustomerInformation.HHString[HH_Length]='\0';


	   memset(gCurrentCustomerInformation.HMString,0x00,sizeof(gCurrentCustomerInformation.HMString));
	   strncpy(gCurrentCustomerInformation.HMString,DBFReadStringAttribute(pDBF,SearchIndex,iHM),HM_Length);
	   gCurrentCustomerInformation.HMString[HM_Length]='\0';

	   memset(gCurrentCustomerInformation.DZString,0x00,sizeof(gCurrentCustomerInformation.DZString));
	   strncpy(gCurrentCustomerInformation.DZString,DBFReadStringAttribute(pDBF,SearchIndex,iDZ),DZ_Length);
	   gCurrentCustomerInformation.DZString[DZ_Length]='\0';

	   memset(gCurrentCustomerInformation.MPHString,0x00,sizeof(gCurrentCustomerInformation.MPHString));
	   strncpy(gCurrentCustomerInformation.MPHString,DBFReadStringAttribute(pDBF,SearchIndex,iMPH),MPH_Length);    
	   gCurrentCustomerInformation.MPHString[MPH_Length]='\0';

	   memset(gCurrentCustomerInformation.MOBILEString,0x00,sizeof(gCurrentCustomerInformation.MOBILEString));
	   strncpy(gCurrentCustomerInformation.MOBILEString,DBFReadStringAttribute(pDBF,SearchIndex,iMOBILE),MOBILE_Length);
	   gCurrentCustomerInformation.MOBILEString[MOBILE_Length]='\0';

	   gCurrentCustomerInformation.MeterReadingDouble =(double)DBFReadIntegerAttribute(pDBF,SearchIndex,iFLA);

	   //printf("��������%f\n",gCurrentCustomerInformation.MeterReadingDouble);

	   memset(gCurrentCustomerInformation.CBSJString,0x00,sizeof(gCurrentCustomerInformation.CBSJString));
	   strncpy(gCurrentCustomerInformation.CBSJString,DBFReadStringAttribute(pDBF,SearchIndex,iCBSJ),CBSJ_Length);
	   gCurrentCustomerInformation.CBSJString[CBSJ_Length]='\0';

	   memset(gCurrentCustomerInformation.CBZTString,0x00,sizeof(gCurrentCustomerInformation.CBZTString));
	   strncpy(gCurrentCustomerInformation.CBZTString,DBFReadStringAttribute(pDBF,SearchIndex,iCBZT),1);
	   gCurrentCustomerInformation.CBZTString[1]='\0';

	   memset(gCurrentCustomerInformation.MeterStateHEX,0x00,sizeof(gCurrentCustomerInformation.MeterStateHEX));
	   strncpy(gCurrentCustomerInformation.MeterStateHEX,DBFReadStringAttribute(pDBF,SearchIndex,iBZTHEX),1);
	   gCurrentCustomerInformation.MeterStateHEX[1]='\0';     

	   memset(gCurrentCustomerInformation.MeterStateSTR,0x00,sizeof(gCurrentCustomerInformation.MeterStateSTR));
	   strncpy(gCurrentCustomerInformation.MeterStateSTR,DBFReadStringAttribute(pDBF,SearchIndex,iBZTSTR),50);
	   gCurrentCustomerInformation.MeterStateSTR[51]='\0';

	   memset(gCurrentCustomerInformation.DCDYString,0x00,sizeof(gCurrentCustomerInformation.DCDYString));
	   strncpy(gCurrentCustomerInformation.DCDYString,DBFReadStringAttribute(pDBF,SearchIndex,iDCDY),1);
	   gCurrentCustomerInformation.DCDYString[1]='\0';    

	   gCurrentCustomerInformation.ReadSignalIntensity=0x00;     
	   gCurrentCustomerInformation.ReadSignalIntensity=DBFReadIntegerAttribute(pDBF,SearchIndex,iXHQD);      

	   memset(gCurrentCustomerInformation.MeterReadMethod,0x00,sizeof(gCurrentCustomerInformation.MeterReadMethod));
	   strncpy(gCurrentCustomerInformation.MeterReadMethod,DBFReadStringAttribute(pDBF,SearchIndex,iSGCQ),1);      
	   gCurrentCustomerInformation.MeterReadMethod[1]='\0';
	   
	   //2016-12-02   �����޸� ����   iSteve Shanghai    
	   	if(iCollectorType==0x02)
		{
			iZDBH = DBFGetFieldIndex(pDBF,"ZDBH");
			//���������    
			memset(gCurrentCustomerInformation.CollectorNoString,0x00,sizeof(gCurrentCustomerInformation.CollectorNoString));
			strncpy(gCurrentCustomerInformation.CollectorNoString,DBFReadStringAttribute(pDBF,SearchIndex,iZDBH),BH_Length);
			gCurrentCustomerInformation.CollectorNoString[BH_Length]='\0';
		}
	   
	   CloseDBF(pDBF);
       return true;
    }

}

/*
* 00 ���ݵ�ַ����¥�����ƣ�����¥�����/С�����
* ������
*      pDBF�����ݿ�ָ��
*     pDoorCode�����ƺ�ָ��
* ����ֵ��
*     ��
*/
void AbstractLDMCfromDZ_UpdateLDXQNo(void)
{

    DBFHandle pDBF;
    int i=0,tRecCount=0,k1=0,k2=0,T=0,n1=0,j=0; //j=0, LineNo=0,
    unsigned char iXQNo,iXQMC,iLDNo,iUserAddr,iLDMC; //sMeterNo_String[CBYJFZBH_LEN+1], sBuildNo[CBEJFZBH_LEN+1],
    char sUserAddr[51]={0},sLDName[51]={0},sXQName[51]={0},DisplayString[101]={0},SequenceNumber_String[10+1]={0};
    //Item_Display iXQList[30]={0},iLDList[60]={0};              
    bool  XQExist_Flag=false,LDExist_Flag=false;
#if Display_ENGLISH
    printf("QueryingTheDatabase...\n");
#else
	printf("���ڲ�ѯ���ݿ�...\n");
#endif
    // ew_display_string(16,(LineNo++)*16,(unsigned char*)"���ڲ�ѯ���ݿ�...",COLOR_BLUE,0x10 | 1);
    // ew_updata_display();
	pDBF=OpenDBF(DBF_DATABASE_FILENAME,"rb+");    
    if (pDBF==NULL)
    {
		clrscr();
#if Display_ENGLISH
        printf("Open database error!\n");
		printf("Any key return...\n");
#else
		printf("�����ݿ����!\n");
		printf("�����������...\n");
#endif        
        getch();
        return ;
    }

    tRecCount=DBFGetRecordCount(pDBF);
    iUserAddr=DBFGetFieldIndex(pDBF,"DZ");
    iXQNo=DBFGetFieldIndex(pDBF,"CBYJFZBH"); //С�����
    iXQMC=DBFGetFieldIndex(pDBF,"CBYJFZMC"); //С������
    iLDNo=DBFGetFieldIndex(pDBF,"CBEJFZBH"); //¥�����
    iLDMC=DBFGetFieldIndex(pDBF,"CBEJFZMC"); //¥������

	if(tRecCount==0)
	{
		clrscr();
#if Display_ENGLISH
        printf("Database is NULL!\n");
		printf("Any key return...\n");
#else
		printf("���ݿ�Ϊ��!\n");
		printf("�����������...\n");
#endif        
		getch();
		CloseDBF(pDBF);
		return;
	}

	clrscr();
#if Display_ENGLISH
    sprintf(DisplayString,"TotalNum:%d",tRecCount);
	printf("%s\n",DisplayString);
	printf("Regrouping...\n");
#else
	sprintf(DisplayString,"�ܼ�¼��:%d",tRecCount);
	printf("%s\n",DisplayString);
	printf("�������·�����...\n");
#endif    
	// ew_display_string(16,(LineNo++)*16,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
	// ew_display_string(16,(LineNo++)*16,(unsigned char*)"�������·�����...",COLOR_BLUE,0x10 | 1);
	// ew_updata_display();
	
	memset(gCommunityList,0x00,sizeof(gCommunityList));
	memset(gBuildingList,0x00,sizeof(gBuildingList));

	//������¥������
    for (i=0,k1=0,k2=0;i<tRecCount;i++)
	{

		//С���������ܳ������ֵ��20
		if((k1>=50)||(k2>=50))    
		{
			clrscr();
	        //ew_clear_client_area(true);
	        if(k1>=10)
	        {
#if Display_ENGLISH
                printf("Commity statistics exceeded%d!\n",10);
#else
				printf("С��ͳ��������%d!\n",10);
#endif
	        	//ew_display_string(16,(LineNo++)*16,(unsigned char*)"С��ͳ��������6000!",COLOR_BLUE,0x10 | 1);
	        }
	        else if(k2>=45)                  
	        {
#if Display_ENGLISH
                printf("Building statistics exceeded%d!\n",45);
#else
				printf("¥��ͳ��������%d!\n",45); 
#endif
		        //ew_display_string(16,(LineNo++)*16,(unsigned char*)"¥��ͳ��������6000!",COLOR_BLUE,0x10 | 1);
	        }
	        // ew_display_string(16,(LineNo++)*16,(unsigned char*)"�����������...",COLOR_BLUE,0x10 | 1);
	        // ew_updata_display();
			getch();
			CloseDBF(pDBF);
			return;
		}

		//������ʾ
//    	LineNo=3;
//		ew_screen_paint_line((LineNo)*16, GUI_COLOR_BLACK); //GUI_COLOR_BLACK
//		sprintf(DisplayString,"���ڴ�����%d����¼!",i);
//		ew_display_string(16,(LineNo)*16,(unsigned char*)DisplayString,COLOR_BLUE,0x10 | 1);
//		LineNo++;
//		ew_updata_display();

        //ȡ����ַ��Ϣ
		memset(sUserAddr,0x00,sizeof(sUserAddr));
        strncpy(sUserAddr,DBFReadStringAttribute(pDBF,i,iUserAddr),DZ_Length);
		for(j=0;j<DZ_Length;j++)  
		{
			if(sUserAddr[j]==0x20) 
			{
				sUserAddr[j]='\0';  
				break;
			}
		}
		sUserAddr[DZ_Length]='\0'; 
		

		//������ַ��Ϣ
		n1=0x00;  
		for(j=0;j<DZ_Length;j++)  
		{
			if(sUserAddr[j]==0x2d)    
			{
				n1=j+1;    
				break; 
			}
		}

		if(strlen(sUserAddr)<=20)  //��ַС��20���ַ�����
		{
			strcpy(sLDName,sUserAddr);
		}
		else
		{
			if((n1>20)||(n1==0x00))//�ָ�������20���ַ�����  ����û�зָ���ŵ����  
			{
				strncpy(sLDName,sUserAddr,ID_Length);
				sLDName[ID_Length]='\0';
			}
			else  //��ַ���ȴ���20���ַ�   �ҷָ���С��20���ַ�����
			{
				strncpy(sLDName,sUserAddr,n1);    
				sLDName[n1]='\0';
			}
		}


		////����¥������   
		 DBFWriteStringAttribute(pDBF,i,iLDMC,sLDName);

		 //*****************************************����С����Ϣ************************************//
		XQExist_Flag = false;
		//ȡ��С����Ϣ
		memset(sXQName,0x20,sizeof(sXQName));
		strncpy(sXQName,DBFReadStringAttribute(pDBF,i,iXQMC),ID_Length);
		for(j=0;j<ID_Length;j++)
		{
			if(sXQName[j]==0x20) 
			{   
				sXQName[j] = '\0';   
				break;
			}
		}
        sXQName[ID_Length] = '\0';
        



        if(k1!=0x00)
		{
			for(T=0;T<k1;T++)
			{
				if(strcmp(sXQName,gCommunityList[T].Item_String)==0)
				{
					 DBFWriteStringAttribute(pDBF,i,iXQNo,gCommunityList[T].MeterNo_String); 
					 XQExist_Flag = true;
				}
			}

			if(XQExist_Flag==false)
			{
				 strcpy(gCommunityList[k1].Item_String,sXQName);
				 sprintf(SequenceNumber_String,"%d",k1);
				 strcpy(gCommunityList[k1].MeterNo_String,SequenceNumber_String);

				 DBFWriteStringAttribute(pDBF,i,iXQNo,SequenceNumber_String);
				 k1++;
			}

		}
		else
		{
           	//��һ����¼
			 strcpy(gCommunityList[0].Item_String,sXQName);
			 strcpy(gCommunityList[0].MeterNo_String,"0");

			 //����С�����
			 DBFWriteStringAttribute(pDBF,i,iXQNo,"0");   
			 k1++;
		}

		 //*************************************����¥����Ϣ****************************************//
		LDExist_Flag = false;
		
		
		//ȡ��¥����Ϣ
		memset(sLDName,0x20,sizeof(sLDName));   
		strncpy(sLDName,DBFReadStringAttribute(pDBF,i,iLDMC),ID_Length);  
		for(j=0;j<ID_Length;j++)   
		{
			if(sLDName[j]==0x20) 
			{     
				sLDName[j] = '\0';  
				break;
			}
		}
		sLDName[ID_Length] = '\0';
		
		
		
        if(k2!=0x00)
		{

			for(T=0;T<k2;T++)
			{
				if(strcmp(sLDName,gBuildingList[T].Item_String)==0)
				{
					 //¥�������Ѿ�����
					 DBFWriteStringAttribute(pDBF,i,iLDNo,gBuildingList[T].MeterNo_String);
					 LDExist_Flag = true;
				}
			}

			if(LDExist_Flag==false)
			{
				 //¥�����Ʋ�����
				 strcpy(gBuildingList[k2].Item_String,sLDName);
				 sprintf(SequenceNumber_String,"%d",k2);
				 strcpy(gBuildingList[k2].MeterNo_String,SequenceNumber_String);
				 DBFWriteStringAttribute(pDBF,i,iLDNo,SequenceNumber_String);
				 k2++;
			 }

		}
		else
		{
           	//��һ����¼
			 strcpy(gBuildingList[0].Item_String,sLDName);  
			 strcpy(gBuildingList[0].MeterNo_String,"0"); 

			 //����¥�����
			 DBFWriteStringAttribute(pDBF,i,iLDNo,"0");
			 k2++;
		}
	}

    clrscr();
#if Display_ENGLISH
    printf("Building updated successfully!\n");
	printf("Any key return...\n");

#else
    printf("����С��¥����Ϣ�ɹ�!\n");
	printf("�����������...\n");
#endif    
    getch();
    CloseDBF(pDBF);
    return ;
}


//******************************************************************************
//** 01 ����
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
void AddMeter_FunApp(void)
{
     FILE  *fp;
	 unsigned char i=0;//LineNo=1;;
	 char  MeterString[16];
     bool   L_NoCalcel;

	 L_NoCalcel = false;
    //////��csv�ļ�
    fp = fopen(UPDATEDATABASE_FILENAME,"a");
    if(fp==NULL)
	{
		clrscr();
		printf("Open MeterList.CSV Failed!\n");
		getch();
		fclose(fp);
		return;
	}

    if(InputNumber_FunApp("�����������ı��ţ�",12,gTargetDeviceNo,true)==true)
	{
		  // if(InputMeterState_FunApp()==TRUE)
		  // {
			 L_NoCalcel = true;
			 strcpy(MeterString,gTargetDeviceNo);
             MeterString[12] = ',';
             // MeterString[13] = gCommMeterState[0];
			 MeterString[13] = 0x31;
             // MeterString[14] = 0x0D;//�س�
             MeterString[14] = 0x0A;//����
             for(i = 0 ;i<15;i++)
			 {
				fputc(MeterString[i],fp);   //////fputs(MeterString,fp); ������ F4 FF
			 }
		  // }

	}
    //////�ر�csv�ļ�
    fclose(fp);

    // if((fp=fopen("MeterList.CSV","r"))==NULL)
	// {
		// clrscr();
		// printf("Open MeterList.CSV Failed!\n");
		// getch();
		// return;
	// }
	// clrscr();
	// while(fgets(MeterString,16,fp)!=NULL)
	// {
	   // printf("%s",MeterString);  //////������ն�  fputs(MeterNo,stdout);
	// }
	// getch();

    //////�ر�csv�ļ�
    // fclose(fp);

	if(L_NoCalcel==true)
	{
		clrscr();
		printf("���ӵ��������!\n");
		printf("�����������...\n");
		getch();
	}
    return;

}

//******************************************************************************
//** 02 ɾ��
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
void DeleteMeter_FunApp(void)
{
	int iKey=0x00;
	unsigned char i=0,j=0,iFlag;//LineNo=1;
	char  MeterString[16];
    bool   L_NoCalcel;
    bool   iFileChangedFlag=true;  
    unsigned char tKey;
    unsigned int  tSel;
    unsigned int  tPage;

			
    //clrscr();
    tSel=1;
    tPage=0;

	//��ȡ�����б�   
	if(iFileChangedFlag==true)      
	{
		iFileChangedFlag=false;		
		L_NoCalcel = false;
		GetMeterList_AppFun('3');
	}
			
    if (gItemSum==0)     
	{
		clrscr();
		printf("����Ϊ��!\n");
		printf("AA�����������...\n");    
        getch();
        return ;
    }
	else
	{
        while (1)      
        {
			if(iFileChangedFlag==true)   
			{
				iFileChangedFlag=false;		
				L_NoCalcel = false;
				GetMeterList_AppFun('3');
			}
			
			tKey=DrawListWithTitleNew(20,"�����б�:",&tSel,&gItemList[0].Item_String[0],0,sizeof(Item_Display),gItemSum,&tPage);
			if (tKey==0x0D)
            {
				clrscr();        
				printf("ɾ��%s��\n",gItemList[tSel-1].Item_String);       
				printf("[ȷ��]ɾ��[ȡ��]�˳�\n");

				iKey=bioskey(0);      
				if (iKey==_ESC)   
				{
					return;
				}
				
            	//��ȡѡ�еļ�¼����
            	strcpy(gTargetDeviceNo,gItemList[tSel-1].Item_String);
				
				///////////////////////����Ҫɾ���ı������⣬��������д��ԭ�ļ�///////////////////////
				for(i=0;i<gItemSum;i++)
				{
					if(strcmp(gItemList[i].Item_String,gTargetDeviceNo)==0)
					{
						L_NoCalcel = true;
						for(j=0;j<gItemSum-i;j++)
						{
							strcpy(gItemList[j+i].Item_String,gItemList[j+i+1].Item_String);
						}
						break;
					}

				}
				
				if(L_NoCalcel == true)
				{
					//д�����ӵĵ���
					gItemSum = gItemSum-1;  
					WriteMeterList_AppFun();
					
					//�´���ʾ�������뵵��  
					iFileChangedFlag = true;  
					clrscr();
					printf("ɾ�����������!\n");
					printf("�����������...\n");
					getch();
				}
				else
				{
					clrscr();
					printf("ɾ�����Ų�����!\n");
					printf("�����������...\n");  
					getch();
				}
				
            }
            else if (tKey==0x27) 
			{
                return;
            }
        }
    }

    //return;
}

//******************************************************************************
//** 02 ɾ��
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
// void DeleteMeter_FunApp(void)
// {
    // FILE  *fp;
	// unsigned char i,j,iFlag;//LineNo=1;
	// char  MeterString[16];
    // bool   L_NoCalcel;

	// L_NoCalcel = false;
	// GetMeterList_AppFun('3');
    // if(InputNumber_FunApp("�����������ı��ţ�",12,gTargetDeviceNo,true)==true)
	// {

		/////////////////////����Ҫɾ���ı������⣬��������д��ԭ�ļ�///////////////////////
		// iFlag = 0;
	    // fp = fopen(UPDATEDATABASE_FILENAME,"w");
		// if(fp==NULL)
		// {
			// clrscr();
			// printf("Open MeterList.CSV Failed!\n");
			// getch();
			// fclose(fp);
			// return;
		// }
		// for(i=0;i<gItemSum;i++)
		// {
			// if(strcmp(gItemList[i].Item_String,gTargetDeviceNo)!=0)
			// {
				// L_NoCalcel = true;
				// strncpy(MeterString,gItemList[i].Item_String,12);
				// MeterString[12] = ',';
				// MeterString[13] = gItemList[i].MeterState[0];
				// MeterString[14] = 0x0A;//����
				// for(j=0;j<15;j++)
				// {
					// fputc(MeterString[j],fp);      //////fputs(MeterString,fp); ������ F4 FF
				// } //////printf("%s",MeterString);

			// }
			// else if(strcmp(gItemList[i].Item_String,gTargetDeviceNo)==0)
			// {
				// iFlag = 1;
			// }

		// }

		// if(iFlag==0)
		// {
			// clrscr();
			// printf("����ı��Ų�����!\n");
			// printf("�����������...\n");
			// getch();
			////�ر�csv�ļ�
			 // fclose(fp);
			 // return;
		// }

		////�ر�csv�ļ�
		// fclose(fp);
	// }

	// if(L_NoCalcel == true)
	// {
		// clrscr();
		// printf("ɾ�����������!\n");
		// printf("�����������...\n");
		// getch();
	// }

    // return;
// }

//******************************************************************************
//** 03 ��ѯ
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
void QueryMeter_FunApp(void)
{
     FILE  *fp;
	 unsigned char i=0,iFlag=0;//LineNo=1;
	 char   MeterString[16];

	///////////////////////////////��ȡ���еı��ż���״̬///////////////////////////////////
    //////�ر�csv�ļ�
    fp = fopen(UPDATEDATABASE_FILENAME,"r");
    if(fp==NULL)
	{
		clrscr();
	 	printf("Open MeterList.CSV Failed!\n");//
		getch();
		fclose(fp);
		return;
	}
    gItemSum=0;
	while(fgets(MeterString,16,fp)!=NULL)
	{
       strncpy(gItemList[gItemSum].Item_String,MeterString,12);
       gItemList[gItemSum].Item_String[12] = '\0';
       gItemList[gItemSum].MeterState[0] = MeterString[13];
       gItemList[gItemSum].MeterState[1] = '\0';
	   gItemSum++;
       // printf("%s",MeterString);  //////������ն�  fputs(MeterNo,stdout);
	}
    //////�ر�csv�ļ�
    fclose(fp);

	// printf("ͳ��:%d\n",gComMeterAcount);
	// getch();//***********************************///

	///////////////////////����Ҫɾ���ı������⣬��������д��ԭ�ļ�///////////////////////
	iFlag = 0;
	if(InputNumber_FunApp("�����������ı��ţ�",12,gTargetDeviceNo,true)==true)
	{
        for(i=0;i<gItemSum;i++)
		{
			if(strcmp(gItemList[i].Item_String,gTargetDeviceNo)==0)
			{
				iFlag = 1;
				strncpy(MeterString,gItemList[i].Item_String,12);
				MeterString[12] = '\0';
				MeterString[13] = gItemList[i].MeterState[0];
				
				clrscr();
                printf("����:%s\n",MeterString);
				if(MeterString[13]==0x31)
				{
					printf("����״̬:δ����!\n");
				}
				else
				{
					printf("����״̬:������!\n");
				}
				printf("�����������...\n");
			 	getch();
                return;
			}

		}
		if(iFlag==0)
		{
		    clrscr();
			printf("����ı��Ų�����!\n");
			printf("�����������...\n");
			getch();
		}
	}
    return;
}

//******************************************************************************
//** 05 д�뵵���б�
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
void WriteMeterList_AppFun(void)
{
	FILE *fp;
	//int LineNo=1;
	int i=0,j=0;
	char MeterString[20]={0};

	printf("\n��ʼ���������д�뵵���б�!\n");

	//����ļ�����
//    fclose(fp);
//	fp=fopen(UPDATEDATABASE_FILENAME,"w+");
//	fclose(fp);
//
//	printf("\n��ʼ���������д�뵵���б�!\n");
//  fclose(fp);

	fp = fopen(UPDATEDATABASE_FILENAME,"w+");
    if(fp==NULL)
	{
		clrscr();
		printf("Open MeterList.CSV Failed!\n");
		getch();
		fclose(fp);
		return;
	}

	// fseek(fp,0,SEEK_SET); //��λ���ļ�ͷλ��
	for(i=0;i<gItemSum;i++)
	{
		strncpy(MeterString,gItemList[i].Item_String,12);
		MeterString[12] = ',';
		MeterString[13] = gItemList[i].MeterState[0];
		MeterString[14] = 0x0A;//����
		for(j=0;j<15;j++)
		{
			 fputc(MeterString[j],fp);      //////fputs(MeterString,fp); ������ F4 FF
		} //////printf("%s",MeterString);
	}
	//�ر�csv�ļ�
	fclose(fp);
}

//******************************************************************************
//** 05 ��ȡ�����б�
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
bool GetMeterList_AppFun(unsigned char sFlag)
{
	FILE  *fp;
	bool  iControlFlag=false;
	char  MeterString[20]={0};
	unsigned char  i,n;//LineNo=1;

	//clrscr();
	//printf("���ڻ�ȡ����...\n");        

	///////////////////////////////��ȡ���еı��ż���״̬///////////////////////////////////
    fp = fopen(UPDATEDATABASE_FILENAME,"r");
    if(fp==NULL)
	{
		clrscr();
		printf("Open MeterList.CSV Failed!\n");
		getch();
		fclose(fp);
		return false;
	}

    gItemSum=0x00;
    memset(gItemList,0x00,sizeof(gItemList));
	//�����������ĳ�е����д����޷ָ�������ָ���ǰ����Ŵ���12λ���֣���Ϊ������Ч��
	while(!feof(fp))
	{
        //��ȡ14���ַ���
		memset(MeterString,0x00,sizeof(MeterString));
        fgets(MeterString,16,fp);

		//printf("�ַ�����%s\n",MeterString);
		//printf("���ȣ�%d\n",strlen(MeterString));

	    //���ҷָ���λ��
	    n = 0;
		if(strlen(MeterString)>1)
		{
			for(i=0;i<14;i++)
			{
			  if(MeterString[i]== 0x2C)
			  {
				  n = i;
			  }
			}
		}

		iControlFlag=false;
	    if((sFlag==0x33)||((sFlag==0x31)&&(MeterString[n+1]!=0x30))||((sFlag==0x30)&&(MeterString[n+1]==0x30))) //���м�¼ && ��ȡδ������������ʧ�ܵı����б�
	    {
	    	iControlFlag = true;
	    }

	    //�ж���Ч����
	    if((n>0)&&(n<13)&&(iControlFlag == true))
		{
			if(n<12) //��Ҫ�ڵ���ǰ�油��0
			{
				//����
				for(i=0;i<12-n;i++)
				{
					gItemList[gItemSum].Item_String[i]= 0x30 ;
				}

				//������Ч����
				for(i=0;i<n;i++)
				{
					gItemList[gItemSum].Item_String[i+12-n]= MeterString[i] ;
				}
			}
			else
			{
				//����
				strncpy(gItemList[gItemSum].Item_String,MeterString,12);
			}

			gItemList[gItemSum].Item_String[12] = '\0';

			//����״̬
			gItemList[gItemSum].MeterState[0] = MeterString[n+1];
			gItemList[gItemSum].MeterState[1] = '\0';

			gItemSum++;
			// for(i=0;i<13;i++)
			// {
				// if(i==6)printf("\n");
				// printf(",%x",gMeterList[gComMeterAcount].MeterNo[i]);
			// }

			// printf("\n%s\n",gMeterList[gComMeterAcount].MeterNo);
			// getch();

		}
// clrscr();
// printf("nֵ:%d\n",n);
// printf("1gCMA:%d\n",gComMeterAcount);
// getch();

	}

    //////�ر�csv�ļ�
    fclose(fp);


    //printf("\n�ܹ���%d\n",gItemSum);
    // for(i=0;i<gItemSum;i++)
	// {
		// printf(",%s",gItemList[i].Item_String);
	// }

	//ͳ��δ�����ı���
//    if(ItemSum>50)
//	{
//		if(gDelete_FunApp!=true)
//		{
//			ew_clear_client_area(true);
//			sprintf(DisplayString,"��������:%d",ItemSum);
//		 	ew_display_string(32,16*(LineNo++),(unsigned char*)DisplayString,COLOR_BLUE,0x10);//
//		 	ew_display_string(32,16*(LineNo++),(unsigned char*)"��������������50��",COLOR_BLUE,0x10);//
//		 	ew_updata_display();
//			getch();
//		}
//		else
//		{
//			gDelete_FunApp = false;
//		}
//		return false;
//	}
    return true;

}

//******************************************************************************
//** 08 ȷ������������
//** ������
//**     ��
//** ����ֵ��
//**     ��
//*****************************************************************************/
bool SearchUpdateIndex_AppFun(void)
{
//
//	unsigned char  LineNo=1,i,j,BitFlag;
//    ew_clear_client_area(true);
//    ew_display_string(16,16*(LineNo++),(unsigned char*)"����ȷ��������������",COLOR_BLUE,0x10);//
// 	ew_updata_display();
//	 for(i=0;i<30;i++)
//	 {
//		if(ReUpdateFlag[i]==0x00)
//		{
//			 continue;
//		}
//		else
//		{
//			BitFlag = 0x01;
//			for(j=0;j<8;j++)
//			{
//				if((ReUpdateFlag[i]&BitFlag)!=0x00) // 1����ʾʧ��
//				{
//					gPackageIndex = (i*8 + j);   //ȷ����Ҫ���͵����ݰ����
//					if(gPackageIndex<gMissingPackageAcountSum)
//					{
//						ReUpdateFlag[i] = (ReUpdateFlag[i] & ~BitFlag) ; //���͵�ǰ������Ӧ�����ݰ������õ�ǰ����λ
//						return true;
//					}
//					else
//					{
//						return false;
//					}
//
//				}
//				else
//				{
//				    BitFlag = BitFlag << 1;
//				}
//			}
//		}
//
//	 }
	 return true;
}


//������ݿ��ļ��е�����
bool CleanDBFDataFromDB(void)
{
	   DBFHandle pDBF;
	   int i=0;
	    int tRecCount;// j,i
	    unsigned char iFLA,iCBSJ,iCBZT,iBZTHEX,iBZTSTR,iXHQD,iCSFS,iCBDY;
	    //char MeterValueString[13]={0},BZTSTRString[26]={0}; //sFLA[12],  sBH[12],

	    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
	    {
	        tRecCount=DBFGetRecordCount(pDBF);

	        for(i=0;i<tRecCount;i++)
	        {
				//iBH=DBFGetFieldIndex(pDBF,"BH"); //����
				iFLA=DBFGetFieldIndex(pDBF,"FLA");//������
				iCBSJ=DBFGetFieldIndex(pDBF,"CBSJ");//����ʱ��
				iCBZT=DBFGetFieldIndex(pDBF,"CBZT");//����״̬
				iBZTHEX=DBFGetFieldIndex(pDBF,"BZTHEX");//��״̬HEX
				iBZTSTR=DBFGetFieldIndex(pDBF,"BZTSTR");//��״̬STR
				iXHQD=DBFGetFieldIndex(pDBF,"XHQD");//�ź�ǿ��
				iCSFS=DBFGetFieldIndex(pDBF,"SGCQ");//������ʽ
				iCBDY=DBFGetFieldIndex(pDBF,"DCDY");//������ѹ


		//
		//	    ew_clear_client_area(true);
		//	    ew_display_string(16,16,(unsigned char*)"���ڴ洢���ݣ�......",COLOR_BLUE,0x10 | 1);
		//      getch();
				//��������
				//sprintf(MeterValueString,"%.0f",gCurrentCustomerInformation.MeterReadingDouble);
				DBFWriteStringAttribute(pDBF,i,iFLA,"0");
				//����״̬
				DBFWriteStringAttribute(pDBF,i,iCBZT,"0");
				//����ʱ��
				DBFWriteStringAttribute(pDBF,i,iCBSJ,"0");
				//��״̬HEX
				DBFWriteStringAttribute(pDBF,i,iBZTHEX,"0");
				//��״̬STR
				DBFWriteStringAttribute(pDBF,i,iBZTSTR,"0");
				//�ź�ǿ��-�����洢
				DBFWriteIntegerAttribute(pDBF,i,iXHQD,0);
				//������ѹ
				DBFWriteStringAttribute(pDBF,i,iCBDY,"0");
				//������ʽ
				DBFWriteStringAttribute(pDBF,i,iCSFS,"0");
	        }
			CloseDB(&pDBF);
			return true;
		}
		else
		{
			 return false;
		}

}

//������ݿ��ļ��е�����       //2016-08-06  Add new function to correct read-meter-data-time for hardware RTC damage
bool ResetDBFTimeFromDB(void)
{

    DBFHandle pDBF;
    int tRecCount,i;// j,i
    unsigned char iCBZT,iCBSJ;
    char TimeString_1[CBSJ_Length+1]={0},TimeString_2[CBSJ_Length+1]={0},iSJString[2]={0}; //sFLA[12],  sBH[12],
#if Display_ENGLISH
    if (InputNumber_FunApp("Please enter time\n 20160806091000��",14,TimeString_1,true)==true)    
	{
		if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
		{
			tRecCount=DBFGetRecordCount(pDBF);

			iCBZT=DBFGetFieldIndex(pDBF,"CBZT");

			iCBSJ=DBFGetFieldIndex(pDBF,"CBSJ");

			clrscr();
			printf("Reseting database time!\n");
			//ew_display_string(32,32,(unsigned char*)"���������ѳ�����ʱ�䣡",COLOR_BLUE,0x10 | 1);
			//getch();

			for(i=0;i<tRecCount;i++)
			{
//				ew_display_string(64,128,(unsigned char*)"......",COLOR_RED,0x50 | 1);
//				ew_os_delay_ms(700);
//				ew_draw_window(64, 128, 96, 32, GUI_COLOR_BLACK);  //���
//				ew_updata_display();

			    //����״̬
				//��ȡС������
				strncpy(iSJString,DBFReadStringAttribute(pDBF,i,iCBZT),1);
				iSJString[1]='\0';
				if(strcmp(iSJString,"0")!=0)
				{
				   TimeString_2[0] = TimeString_1[0]; //��
				   TimeString_2[1] = TimeString_1[1];
				   TimeString_2[2] = TimeString_1[2];
				   TimeString_2[3] = TimeString_1[3];
				   TimeString_2[4] = '-';
				   TimeString_2[5] = TimeString_1[4];//��
				   TimeString_2[6] = TimeString_1[5];
				   TimeString_2[7] = '-';
				   TimeString_2[8] = TimeString_1[6];//��
				   TimeString_2[9] = TimeString_1[7];
				   TimeString_2[10] = ' ';
				   TimeString_2[11] = TimeString_1[8];//ʱ
				   TimeString_2[12] = TimeString_1[9];
				   TimeString_2[13] = ':';
				   TimeString_2[14] = TimeString_1[10];//��
				   TimeString_2[15] = TimeString_1[11];
				   TimeString_2[16] = ':';
				   TimeString_2[17] = TimeString_1[12];//��
				   TimeString_2[18] = TimeString_1[13];
				   TimeString_2[19]='\0';
				   //����ʱ��
				   DBFWriteStringAttribute(pDBF,i,iCBSJ,TimeString_2);
				}
			}

			CloseDB(&pDBF);

			clrscr();
			printf("Reseted database time!\n");
			printf("Any key return...\n");
			getch();
			return true;
		}
		else
		{
			 return false;
		}
	}
	else
	{
		 return false;
	}
#else
	if (InputNumber_FunApp("����ʱ��\n 20160806091000��",14,TimeString_1,true)==true)    
	{
		if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)
		{
			tRecCount=DBFGetRecordCount(pDBF);

			iCBZT=DBFGetFieldIndex(pDBF,"CBZT");

			iCBSJ=DBFGetFieldIndex(pDBF,"CBSJ");

			clrscr();
			printf("���������ѳ�����ʱ��!\n");
			//ew_display_string(32,32,(unsigned char*)"���������ѳ�����ʱ�䣡",COLOR_BLUE,0x10 | 1);
			//getch();

			for(i=0;i<tRecCount;i++)
			{
//				ew_display_string(64,128,(unsigned char*)"......",COLOR_RED,0x50 | 1);
//				ew_os_delay_ms(700);
//				ew_draw_window(64, 128, 96, 32, GUI_COLOR_BLACK);  //���
//				ew_updata_display();

			    //����״̬
				//��ȡС������
				strncpy(iSJString,DBFReadStringAttribute(pDBF,i,iCBZT),1);
				iSJString[1]='\0';
				if(strcmp(iSJString,"0")!=0)
				{
				   TimeString_2[0] = TimeString_1[0]; //��
				   TimeString_2[1] = TimeString_1[1];
				   TimeString_2[2] = TimeString_1[2];
				   TimeString_2[3] = TimeString_1[3];
				   TimeString_2[4] = '-';
				   TimeString_2[5] = TimeString_1[4];//��
				   TimeString_2[6] = TimeString_1[5];
				   TimeString_2[7] = '-';
				   TimeString_2[8] = TimeString_1[6];//��
				   TimeString_2[9] = TimeString_1[7];
				   TimeString_2[10] = ' ';
				   TimeString_2[11] = TimeString_1[8];//ʱ
				   TimeString_2[12] = TimeString_1[9];
				   TimeString_2[13] = ':';
				   TimeString_2[14] = TimeString_1[10];//��
				   TimeString_2[15] = TimeString_1[11];
				   TimeString_2[16] = ':';
				   TimeString_2[17] = TimeString_1[12];//��
				   TimeString_2[18] = TimeString_1[13];
				   TimeString_2[19]='\0';
				   //����ʱ��
				   DBFWriteStringAttribute(pDBF,i,iCBSJ,TimeString_2);
				}
			}

			CloseDB(&pDBF);

			clrscr();
			printf("������ѳ�����ʱ������!\n");
			printf("�����������...\n");
			getch();
			return true;
		}
		else
		{
			 return false;
		}
	}
	else
	{
		 return false;
	}
#endif    
}

/*
* ���ܣ� ��ȡ�������б� - ���ձ��   ZDBH   12
* ������
*        iType    1:���������     2:����������
* ����ֵ��
*        true���޼�������true: �м�����  ��������
*
*/
bool GetCollectorNoNameList_AppFun(int iType)
{
    DBFHandle pDBF;
    int i=0,j=0,k=0,m=0,tRecCount=0;//,n     
    int iSearchIndex=0x00,iSearchDataLength=0x00;   
    char sSearchString[100]={0},sTMPString[100]={0};//ttt[3];    
    bool iRepeat=false;

    //CleanAll();
    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)   
    {

        gCommunitySum = 0;
        tRecCount=DBFGetRecordCount(pDBF);
        
		//iID=DBFGetFieldIndex(pDBF,"ID");
		if(iType==0x01)
		{
			iSearchDataLength = 12;
			iSearchIndex=DBFGetFieldIndex(pDBF,"ZDBH");//���������
		}
		else
		{ 
			iSearchDataLength = 50;
			iSearchIndex=DBFGetFieldIndex(pDBF,"ZDMC");//���������� 
	    }
        //���ڲ�ѯ���ݿ�
    	// clrscr();
        // printf("���ڲ�ѯ���ݿ�...\n");  
        memset(gCommunityList,0x00,sizeof(gCommunityList));
        for (i=0;i<tRecCount;i++)  
        {
		   memset(sSearchString,0x20,sizeof(sSearchString));    
		   memset(sTMPString,0x20,sizeof(sTMPString));
           strncpy(sTMPString,DBFReadStringAttribute(pDBF,i,iSearchIndex),iSearchDataLength);     
           for (j=0;j<(iSearchDataLength+1);j++)
           {
               if(sTMPString[j]==0x20)     
               {
            	   sTMPString[j]='\0';	      			   
				   if(j>20)  
				   {
					    m=0;
					    m=j-20-1;  
						if(iInterceptionLocationPossibility(sTMPString,iSearchDataLength,m)!=true)
						{
							j++;
							m=m+1;
						}	
				        for(k=m;k<j;k++)        
						{
							 sSearchString[k-m] = sTMPString[k]; 
						}
						
						sSearchString[j-m+1]='\0'; 
						//sSearchString[20]='\0';   
				   }
				   else
				   {
					   strcpy(sSearchString,sTMPString);
				   }
				        
            	   break;
               }
           }
//           sSearchString[50]='\0';
           // strcpy(sSearchString,"HelloWorld");
    	   //ew_display_string(32,(i+1)*16,(unsigned char* )sSearchString,COLOR_BLUE,0x10| 0x01);//


    	    if(iRepeat==true)
    	    {
    		    iRepeat = false;
    	    }

    	    for(j=0;j<gCommunitySum;j++)
    		{
    			if(strcmp(gCommunityList[j].Item_String,sSearchString)==0)
    			{
    				iRepeat = true;
    				break;
    			}
    		}

    	    if(iRepeat==false)
    	    {
    			strcpy(gCommunityList[gCommunitySum].Item_String,sSearchString);   
    			gCommunityList[gCommunitySum].Item_Index = i;  
    			gCommunitySum++;
    	    }

        }

    	CloseDB(&pDBF);
    	return true;
    }
    else
    {
    	return false;   
    }
}

/***************************************************************************
 �������б���Ϣ
 ������   
		Title����ʾ����
		Item_List����ʾ�б�
		iCollectorType��   1:�����     2�������� 
 ����ֵ��    
		��  
***************************************************************************/
void CollectorNoNameListApp(const char Title[],Item_Display Item_List[], int ItemSum, int iCollectorType)
{
	unsigned char tKey=0;//WC_Sum=0,YC_Sum=0; //i,     unsigned char KeyValue=0xFF;
    unsigned int tSel,tPage;

    clrscr();
    tSel=1;
    tPage=0;
    if(ItemSum==0)
    {
    	//����
		clrscr();
#if Display_ENGLISH
        printf("Community Information\nis Null!\n"); 
		printf("Please enter AnyKey Return...\n");
#else
		printf("������ϢΪ��!\n"); 
		printf("�����������...\n");
#endif        
        getch();
		return;
    }
    else
    {   
        while (1)
        {
			tKey=DrawListWithTitleNew(20,(unsigned char *)Title,&tSel,&Item_List[0].Item_String[0],0,sizeof(Item_Display),ItemSum,&tPage);
			if (tKey==0x0D) 
            {
            	//��ȡѡ���С������         
            	strcpy(gCommunityName,gCommunityList[tSel-1].Item_String);
				
				//ѡ��ǰ�������Ĳ���
				CollectorReadingByNoName_FunApp(iCollectorType);  
            }
			else if (tKey==0x27)   
			{
                return;
            }
        }
    }
}


/*
* ���ܣ���ȡ���б� 
* ������
*      iCollectorSearchType:  ��������������      1�������       2��������-    
*      iSearchMeterTyep:  ���ұ��ߵ�����     ȫ��-0/�ѳ�-1/δ��-2    
*      iDisplayType:�б���ʾ����    ����-0/����-1/���ƺ�-2/��ַ-3    
* ����ֵ��
*      TRUE�������ɹ�       FALSE������ʧ�ܣ�
*/
bool GetMeterLishByCollector_FunApp(int iCollectorSearchType,int iSearchMeterTyep,int iDisplayType)   
{
    DBFHandle pDBF;
	int i=0,j=0,k=0,m=0;
	int tRecCount=0,iDataLength=0x00;      
    unsigned char iSearchIndex=0,iCBZT,iBH,iHH,iHM,iMPH,iDZ,iOtherIndex=0;  // iID, 
    char sSearchString[100]={0},sTMPString[100]={0},sMeterStateString[3]={0},iMeterStateString[3]={0}; 
	char sMeterNoString[BH_Length+1]={0},sHHString[HH_Length+1]={0},sHMString[HM_Length+1]={0},sMPHString[MPH_Length+1]={0},sDZString[DZ_Length+1]={0};
   // bool iRepeat=false;
	

   
    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)      
    {
		iBH = DBFGetFieldIndex(pDBF,"BH");    
		iCBZT = DBFGetFieldIndex(pDBF,"CBZT");    
		iHH = DBFGetFieldIndex(pDBF,"HH");    
		iHM = DBFGetFieldIndex(pDBF,"HM");    	
		iMPH = DBFGetFieldIndex(pDBF,"MPH");    
		iDZ = DBFGetFieldIndex(pDBF,"DZ");     
		
		//�ж�����  
		if(iCollectorSearchType==0x01)//���Ҽ����������gCommunityName�����б� 
		{
			iDataLength = BH_Length; //12 iOtherIndex
			iSearchIndex=DBFGetFieldIndex(pDBF,"ZDBH");//���������    
		}
		else if(iCollectorSearchType==0x02) //���Ҽ�����������gCommunityName�����б� 
		{    
			iDataLength = HM_Length; //50  
			iSearchIndex=DBFGetFieldIndex(pDBF,"ZDMC");//����������        
		}
	
		
    	gItemSum = 0;
		memset(gItemList,0x00,sizeof(gItemList));     
		
		tRecCount=DBFGetRecordCount(pDBF);
        for (i=0;i<tRecCount;i++)
        {
			
					
			//���ڲ�ѯ���ݿ�   
    		//*********ͬһ����������ͬ��Ҫ��ı���*********//     
			// memset(sSearchString,0x00,sizeof(sSearchString));    
			// strcpy(sSearchString,DBFReadStringAttribute(pDBF,i,iSearchindex)); 		
			
		   memset(sSearchString,0x20,sizeof(sSearchString));     
		   memset(sTMPString,0x20,sizeof(sTMPString));  
           strncpy(sTMPString,DBFReadStringAttribute(pDBF,i,iSearchIndex),iDataLength);          
           for (j=0;j<(iDataLength+1);j++)
           {
               if(sTMPString[j]==0x20)     
               {
            	   sTMPString[j]='\0';				   
				   if(j>20)  
				   {
					    m=0;
					    m=j-20-1;  
						if(iInterceptionLocationPossibility(sTMPString,iDataLength,m)!=true)
						{
							j++;
							m=m+1;
						}	
				        for(k=m;k<j;k++)
						{
							 sSearchString[k-j+21] = sTMPString[k]; 
						}
						
						sSearchString[j-m+1]='\0'; 
						//sSearchString[20]='\0';   
				   }
				   else
				   {
					   strcpy(sSearchString,sTMPString);
				   }  
            	   break;
               }
           }  
			
			//����״̬ 
			memset(sMeterStateString,0x00,sizeof(sMeterStateString));       
			strncpy(sMeterStateString,DBFReadStringAttribute(pDBF,i,iCBZT),1);  
			sMeterStateString[1]='\0';                

			// clrscr();        
			// printf("gCommunityName:\n%s\n",gCommunityName);       
			// printf("iDataLength: %d\n",iDataLength);   
			// printf("AC: %s\n",DBFReadStringAttribute(pDBF,i,iSearchIndex));   	  		
			// printf("sSearchString: %s\n",sSearchString);      
			// printf("��ȡ״̬:\n%s\n",sMeterStateString);         
			// printf("����:\n%d\n",iSearchMeterTyep);        
			// getch();   
			// CloseDB(&pDBF);   
			// return false;          
			
			//�жϻ�ȡ���б�����
			if(iSearchMeterTyep==0x01) //�ѳ�
			{   
				strcpy(iMeterStateString,"1");
			}
			else if(iSearchMeterTyep==0x02)//δ��  
			{
				if(strcmp(sMeterStateString,"2")==0)  
				{
					strcpy(iMeterStateString,"2"); 
				}
				else
				{
					 strcpy(iMeterStateString,"0");     
				}      
			}
			else  //����
			{
				strcpy(iMeterStateString,sMeterStateString);    
			}
			
			//��ȡͬһ������������ı���  
			if((strcmp(gCommunityName,sSearchString)==0)&&(strcmp(sMeterStateString,iMeterStateString)==0))  
    	    {   
				switch(iDisplayType)
				{
					case 0://����
						memset(sHHString,0x20,sizeof(sHHString)); 
						strncpy(sHHString,DBFReadStringAttribute(pDBF,i,iHH),HH_Length);
						for (j=0;j<(HH_Length+1);j++)
						{
							if(sHHString[j]==0x20)
							{
								sHHString[j]='\0';  
								break;
							}
						}
						//���ӱ�����ʾ��ʽ
						strcpy(gItemList[gItemSum].Item_String,sHHString);   
						break;
					case 1://����
						memset(sHMString,0x20,sizeof(sHMString));
						strncpy(sHMString,DBFReadStringAttribute(pDBF,i,iHM),HM_Length);
						for (j=0;j<(HM_Length+1);j++)
						{
							if(sHMString[j]==0x20)
							{
								sHMString[j]='\0';
								break;
							}
						}
						//���ӱ�����ʾ��ʽ
						strcpy(gItemList[gItemSum].Item_String,sHMString);      
						break;
					case 2://���ƺ� 
						memset(sMPHString,0x20,sizeof(sMPHString));
						strncpy(sMPHString,DBFReadStringAttribute(pDBF,i,iMPH),MPH_Length);  
						for (j=0;j<(MPH_Length+1);j++)   
						{
							if(sMPHString[j]==0x20)
							{
								sMPHString[j]='\0';
								break;
							}
						}
						//���ӱ�����ʾ��ʽ
						strcpy(gItemList[gItemSum].Item_String,sMPHString);
						break;
					case 3: //��ַ
						memset(sDZString,0x20,sizeof(sDZString));
						strncpy(sDZString,DBFReadStringAttribute(pDBF,i,iDZ),DZ_Length);
						for (j=0;j<(DZ_Length+1);j++)  
						{  
							if(sDZString[j]==0x20)
							{
								sDZString[j]='\0';
								break;  
							}
						}
						//���ӱ�����ʾ��ʽ 
						strcpy(gItemList[gItemSum].Item_String,sDZString);
						break;
				}
				
                //���ӱ��߱��
				memset(sMeterNoString,0x20,sizeof(sMeterNoString));
				strncpy(sMeterNoString,DBFReadStringAttribute(pDBF,i,iBH),BH_Length);     
				for (j=0;j<(BH_Length+1);j++)  
				{
					if(sMeterNoString[j]==0x20)
					{
						sMeterNoString[j]='\0';
						break;
					}
				}
				strcpy(gItemList[gItemSum].MeterNo_String,sMeterNoString);
				
				
				
				//���ݼ�������ַ����ȡ��������� 
				if(iCollectorSearchType == 0x02)     
				{
					iOtherIndex=DBFGetFieldIndex(pDBF,"ZDBH");//���������  
					memset(gItemList[gItemSum].iSecondaryString,0x20,sizeof(gItemList[gItemSum].iSecondaryString));
					strncpy(gItemList[gItemSum].iSecondaryString,DBFReadStringAttribute(pDBF,i,iOtherIndex),BH_Length);     
					for(j=0;j<(BH_Length+1);j++)    
					{
						if(gItemList[gItemSum].iSecondaryString[j]==0x20)  
						{
							gItemList[gItemSum].iSecondaryString[j]='\0';
							break;
						}
					}
				}
				
				   
				
				//������Ϣ  
				if(gDebugSwittchFlag == true)  
				{
					fputs("\n",gFP);   
					fputs(gItemList[gItemSum].iSecondaryString,gFP);  
				}
				
				
				//���ӱ�������
				gItemList[gItemSum].Item_Index = i;
				gItemSum++;  
    		}

        }
    	CloseDB(&pDBF);
        return true;
    }
    else
    {
    	return false;
    }
}

/*
* ���ܣ�����������ͳ��
* ������ 
*       StatisticsType��ͳ������   0--ȫ������������ͳ��   1--ʵʱ����������ͳ��    2--��������������ͳ��  
*       iType:  0: ��С��¥���Զ�����   1�������   2��������      
* ����ֵ��
*       TRUE�������ɹ���FALSE������ʧ�ܣ�  
*/ 
bool CollectorReadingStatistics_FunApp(int *WC_Sum, int *YC_Sum,int StatisticsType, int iType)
{
    DBFHandle pDBF;  //   
    unsigned char  i=0,j=0,m=0,k=0,tRecCount=0,iDataLength=0;            
	unsigned char iCBZT=0,iSearchIndex=0;         
    char sCBZT[5]={0},sSearchString[101]={0},sTMPString[101]={0}; //sFLA[12],           

    *YC_Sum = 0;
    *WC_Sum = 0;
	
	if(StatisticsType==0x01)
	{
		clrscr();
		printf("����ͳ�Ƽ���������ʵ\nʱ���...\n");
	}
	else
	{
		clrscr();
		printf("����ͳ�Ƽ�����������\n�����...\n");      
	}
	
	
    if(OpenDB(&pDBF,DBF_DATABASE_FILENAME)==true)        
    {
        tRecCount=DBFGetRecordCount(pDBF);
        iCBZT=DBFGetFieldIndex(pDBF,"CBZT");

		if(iType==0x01) // 1������� 
		{
			iDataLength = BH_Length; //12
			iSearchIndex=DBFGetFieldIndex(pDBF,"ZDBH");
		}
		else if(iType==0x02) // 2��������          
		{
			iDataLength = HM_Length; //50  
			iSearchIndex=DBFGetFieldIndex(pDBF,"ZDMC");    
		}
		
        for(i=0;i<tRecCount;i++)
        {	
			
			//��ȡС������	
		    memset(sSearchString,0x20,sizeof(sSearchString));     
		    memset(sTMPString,0x20,sizeof(sTMPString));  
            strncpy(sTMPString,DBFReadStringAttribute(pDBF,i,iSearchIndex),iDataLength);          
            for (j=0;j<(iDataLength+1);j++)
            {
               if(sTMPString[j]==0x20)     
               {
            	    sTMPString[j]='\0';				   
				    if(j>20)  
				    {
					    m=0;
					    m=j-20-1;  
						if(iInterceptionLocationPossibility(sTMPString,iDataLength,m)!=true)
						{
							j++;
							m=m+1;
						}	
				        for(k=m;k<j;k++)
						{
							 sSearchString[k-j+21] = sTMPString[k]; 
						}
						
						 sSearchString[j-m+1]='\0'; 
						 //sSearchString[20]='\0';   
				    }
				    else
				    {
					     strcpy(sSearchString,sTMPString);
				    }  
            	    break;
               }   
            }  
			
			// clrscr();
			// printf("iType:%d\n",iType);        
			// printf("AA:%s\n",DBFReadStringAttribute(pDBF,i,iSearchIndex));    
			// printf("sSearchString:\n%s\n gCommunityName:\n%s\n",sSearchString,gCommunityName);      
			// getch();
			// CloseDB(&pDBF);  
			// return false ;
			
			if(strcmp(sSearchString,gCommunityName)==0)
			{
				//��ȡС���û��ĳ���״̬   
				
				// clrscr();
				// printf("����״̬��%s\n",DBFReadStringAttribute(pDBF,i,iCBZT));   
				// getch();
				
				strncpy(sCBZT,DBFReadStringAttribute(pDBF,i,iCBZT),2);
				sCBZT[1]='\0';
				if(strcmp(sCBZT,"1")==0)
				{
					 (*YC_Sum)++;
				}
				else
				{
					 (*WC_Sum)++;      
				}

			}

        }

		CloseDB(&pDBF);
		return true;
    }
	else
	{
		 clrscr();
		 printf("�����ݿ�ʧ��!\n");
		 printf("�����������...\n");   
		 getch();  
		 return false;
	}
}


