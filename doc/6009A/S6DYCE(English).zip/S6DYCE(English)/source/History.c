
/*
 * ------------------------------------------------------------------------------------------
 * Instruction:
 *          This file is created for recording the program modification:
 * Format:
 *          Name:      Time:        Reason��                Project:
 * Note:
 *          Any Special modification made to this program, details shall be record in time !
 * ------------------------------------------------------------------------------------------
 */


/*
 * Name: Steve.W
 * Time: 2015-07-27
 * EditRecord: Project Created
 * Project: ShenZhen MingCheng  MS300
 */



/*
 * Name: Steve.W
 * Time: 2016-02-15
 * EditRecord: Publish The Program
 * Project: ShenZhen MingCheng  MS300  General Edition V1.0.0
 */

/*
 * Name: Steve.W
 * Time: 2016-04-13
 * EditRecord: Modify The Regroup Function, And Switch The Signal Value Direction
 * Project: ShenZhen MingCheng  MS300  General Edition V1.0.0
 */

/*
 * Name: Steve.W
 * Time: 2016-08-05
 * EditRecord: Correct Manual Input Meter Value Error
 * Project: Publish HeLong Program V1.0.1
 */

/*
 * Name: Steve.W
 * Time: 2016-08-10
 * EditRecord: Add Low-Power-Consumption Function ,Clear DataBase Function, Correct Database Time Manually Function
 * Project: ShenZhen MingCheng  MS300  General Edition V1.0.2
 */
