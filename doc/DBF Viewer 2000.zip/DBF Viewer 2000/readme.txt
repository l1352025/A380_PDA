	Thank for you trying  DBF Viewer 2000

	

Contents
--------
Whats New
Program Information
Company Information
Description
Installation
Registration

What's New
---------
Please visit the DBF Viewer 2000 site for the latest news:
http://www.dbf2002.com/news.html

Program Information
-------------------

Program name:

	DBF Viewer 2000

Program version:
	5.95

Program description:
	
	Powerful Viewer and Editor for DBF files (Clipper, Foxpro, VFP, dBase, DB2K, VO)

Target OS:
	Windows 2000/XP/Vista/2008/Windows 7/8/8.1/10 (32/64)

Company Information
-------------------

HiBase Group

Contact email:
	support@dbf2002.com
Contact WWW URL:
	http://www.dbf2002.com


Description
-----------
DBF Viewer 2000 is a powerful, compact and easy-to-use viewer and editor for DBF files
(Clipper, dBase, FoxBase, Foxpro, Visual Foxpro, Visual DBase, VO, DB2K...).
You can view, edit, sort, use query by example, delete duplicates, create,
print dbf file and export the data from them to a variety of formats
(DBF, TXT, CSV, Excel, HTML, XML, PRG, SQL, RTF) without using any packages and more...


DBF Viewer 2000  is a shareware product. You may use a free
evaluation version of the program for a period of 30 days. Following this
period, if you wish to continue to use DBF Viewer 2000, you MUST register,
or stop using it and remove it from your computer.

Registration
------------
http://www.dbf2002.com/order.html


  	




Copyright (C) HiBase Group, 2001-2015